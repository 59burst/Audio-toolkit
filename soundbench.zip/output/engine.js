const clamp = (value, low, high) => Math.min(high, Math.max(low, value));

class AudioEngine {
  constructor() {
    this.clicks = new Set();
    this.events = [];
    this.beat = 0;
    this.timer = null;
    this.pitchEnabled = true;
  }

  async wake() {
    if (!this.context) {
      const Context = window.AudioContext;
      if (!Context) throw new Error('Audio is unavailable in this browser.');
      this.context = new Context();
      this.output = this.context.createGain();
      this.output.gain.value = 0.8;
      this.output.connect(this.context.destination);
      this.context.addEventListener('statechange', () => this.onState?.());
    }
    if (this.context.state !== 'running') await this.context.resume();
  }

  async startMic() {
    if (!navigator.mediaDevices?.getUserMedia) throw new Error('Microphone access requires HTTPS or localhost.');
    const ready = this.wake();
    let stream;
    let failed = false;
    try {
      [stream] = await Promise.all([
        navigator.mediaDevices.getUserMedia({
          audio: {channelCount: 1, echoCancellation: false, noiseSuppression: false, autoGainControl: false}
        }).then(result => {
          if (failed) result.getTracks().forEach(track => track.stop());
          stream = result;
          return result;
        }),
        ready
      ]);
      if (!this.context.audioWorklet) throw new Error('Microphone analysis requires AudioWorklet support.');
      this.workletReady ??= this.context.audioWorklet.addModule('capture.js').catch(error => {
        this.workletReady = null;
        throw error;
      });
      await this.workletReady;
      this.stream = stream;
      const context = this.context;
      this.source = context.createMediaStreamSource(stream);
      this.capture = new AudioWorkletNode(context, 'input-capture', {
        numberOfInputs: 2, channelCount: 1, channelCountMode: 'explicit', outputChannelCount: [1]
      });
      this.capture.port.postMessage({enabled: this.pitchEnabled});
      this.capture.port.onmessage = ({data}) => {
        if (this.pitchEnabled && this.stream === stream) this.onPitch?.(data);
      };
      this.raw = context.createAnalyser();
      this.weighted = context.createAnalyser();
      this.raw.fftSize = this.weighted.fftSize = 2048;
      this.samples = new Float32Array(2048);
      this.sink = context.createGain();
      this.sink.gain.value = 0;
      this.sink.connect(context.destination);
      this.pitchFilter = context.createBiquadFilter();
      this.pitchFilter.type = 'highpass';
      this.pitchFilter.frequency.value = 70;
      this.pitchFilter.Q.value = -3;
      this.source.connect(this.pitchFilter).connect(this.capture).connect(this.sink);
      this.source.connect(this.capture, 0, 1);
      this.source.connect(this.raw).connect(this.sink);
      this.filters = this.makeWeighting();
      let last = this.source;
      for (const filter of this.filters) last = last.connect(filter);
      last.connect(this.weighted).connect(this.sink);
      for (const track of stream.getAudioTracks()) {
        track.addEventListener('ended', () => {
          if (this.stream !== stream) return;
          this.stopMic();
          this.onState?.();
        });
      }
    } catch (error) {
      failed = true;
      if (this.stream && this.stream === stream) this.stopMic();
      else stream?.getTracks().forEach(track => track.stop());
      throw error;
    }
  }

  makeWeighting() {
    const context = this.context;
    const rate = context.sampleRate;
    const reference = 2 * Math.PI * 1000 / rate;
    let magnitude = 1;
    // Bilinear transform of the six analog poles and four DC zeros.
    const filters = [20.598997, 20.598997, 107.65265, 737.86223, 12194.217, 12194.217].map((hz, index) => {
      const ratio = Math.PI * hz / rate;
      const pole = (ratio - 1) / (ratio + 1);
      const sign = index < 4 ? -1 : 1;
      const gain = (index < 4 ? 1 : ratio) / (ratio + 1);
      magnitude *= gain * Math.hypot(1 + sign * Math.cos(reference), sign * Math.sin(reference))
        / Math.hypot(1 + pole * Math.cos(reference), pole * Math.sin(reference));
      return context.createIIRFilter([gain, sign * gain], [1, pole]);
    });
    const normalization = context.createGain();
    normalization.gain.value = 1 / magnitude;
    return [...filters, normalization];
  }

  stopMic() {
    this.stream?.getTracks().forEach(track => track.stop());
    for (const node of [this.source, this.pitchFilter, this.capture, this.raw, this.weighted, this.sink, ...(this.filters || [])]) node?.disconnect();
    if (this.capture) this.capture.port.onmessage = null;
    this.stream = this.capture = this.source = this.pitchFilter = this.raw = this.weighted = this.sink = this.filters = null;
  }

  setPitchEnabled(enabled) {
    if (enabled === this.pitchEnabled) return;
    this.pitchEnabled = enabled;
    this.capture?.port.postMessage({enabled});
  }

  db(weighted = false) {
    if (!this.stream || this.context.state !== 'running') return null;
    (weighted ? this.weighted : this.raw).getFloatTimeDomainData(this.samples);
    const power = this.samples.reduce((sum, value) => sum + value * value, 0) / this.samples.length;
    return 10 * Math.log10(Math.max(power, 1e-10));
  }

  click(time, accent) {
    const context = this.context;
    const osc = context.createOscillator();
    const envelope = context.createGain();
    osc.frequency.setValueAtTime(accent ? 1580 : 1040, time);
    osc.frequency.exponentialRampToValueAtTime(accent ? 900 : 630, time + 0.035);
    envelope.gain.setValueAtTime(0.0001, time);
    envelope.gain.exponentialRampToValueAtTime(accent ? 0.30 : 0.17, time + 0.002);
    envelope.gain.exponentialRampToValueAtTime(0.0001, time + 0.045);
    osc.connect(envelope).connect(this.output);
    this.clicks.add(osc);
    osc.onended = () => { this.clicks.delete(osc); osc.disconnect(); envelope.disconnect(); };
    osc.start(time);
    osc.stop(time + 0.05);
  }

  startMetro(getTempo, getBeats) {
    this.stopMetro();
    this.nextBeat = this.context.currentTime + 0.045;
    this.beat = 0;
    let swingSide = 1;
    const schedule = () => {
      if (this.context.state !== 'running') return;
      const now = this.context.currentTime;
      const period = 60 / getTempo();
      const beats = getBeats();
      if (this.nextBeat < now) {
        const missed = Math.ceil((now - this.nextBeat) / period);
        this.nextBeat += missed * period;
        this.beat = (this.beat + missed) % beats;
        if (missed % 2) swingSide *= -1;
      }
      while (this.nextBeat < now + 0.1) {
        this.beat %= beats;
        this.click(this.nextBeat, this.beat === 0);
        this.events.push({time: this.nextBeat, beat: this.beat, period, accent: this.beat === 0, swingSide});
        swingSide *= -1;
        this.nextBeat += period;
        this.beat++;
      }
      while (this.events[0]?.time < now - 2.5) this.events.shift();
    };
    schedule();
    this.timer = setInterval(schedule, 25);
  }

  stopMetro() {
    clearInterval(this.timer);
    this.timer = null;
    this.events.length = 0;
    for (const click of this.clicks) click.stop();
  }

  playbackTime() {
    const stamp = this.context.getOutputTimestamp?.();
    if (stamp?.performanceTime > 0) {
      return Math.min(this.context.currentTime, stamp.contextTime + (performance.now() - stamp.performanceTime) / 1000);
    }
    return Math.max(0, this.context.currentTime - (this.context.outputLatency || this.context.baseLatency || 0));
  }

  startTone(type, hz, gain, sweep) {
    this.stopTone();
    const context = this.context;
    const osc = context.createOscillator();
    const envelope = context.createGain();
    const start = context.currentTime;
    const end = sweep ? start + sweep.duration : Infinity;
    osc.type = type;
    osc.frequency.setValueAtTime(sweep ? sweep.from : hz, start);
    envelope.gain.setValueAtTime(0, start);
    envelope.gain.linearRampToValueAtTime(gain, start + 0.018);
    osc.connect(envelope).connect(this.output);
    this.tone = {osc, envelope, start, end, sweep};
    osc.onended = () => {
      osc.disconnect();
      envelope.disconnect();
      if (this.tone?.osc === osc) {
        this.tone = null;
        this.onState?.();
      }
    };
    osc.start(start);
    if (sweep) {
      osc.frequency.exponentialRampToValueAtTime(sweep.to, end);
      envelope.gain.setTargetAtTime(0, end, 0.006);
      osc.stop(end + 0.035);
    }
  }

  updateTone(type, hz, gain) {
    const tone = this.tone;
    if (!tone) return;
    const now = this.context.currentTime;
    tone.osc.type = type;
    if (!tone.sweep) tone.osc.frequency.setTargetAtTime(hz, now, 0.015);
    if (now < tone.end) {
      tone.envelope.gain.cancelScheduledValues(now);
      tone.envelope.gain.setTargetAtTime(gain, now, 0.01);
      if (tone.sweep) tone.envelope.gain.setTargetAtTime(0, tone.end, 0.006);
    }
  }

  stopTone() {
    const tone = this.tone;
    if (!tone) return;
    this.tone = null;
    const now = this.context.currentTime;
    tone.envelope.gain.cancelScheduledValues(now);
    tone.envelope.gain.setTargetAtTime(0, now, 0.006);
    tone.osc.stop(Math.min(now + 0.035, tone.end + 0.035));
  }
}
