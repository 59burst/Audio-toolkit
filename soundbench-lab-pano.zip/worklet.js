const WINDOW = 4096;
const HOP = 1024;

class PanoYin extends AudioWorkletProcessor {
  constructor() {
    super();
    this.ring = new Float32Array(WINDOW);
    this.detectorInput = new Float32Array(WINDOW);
    this.firstLag = Math.max(2, Math.floor(sampleRate / 1300));
    this.lastLag = Math.min(WINDOW - 2, Math.ceil(sampleRate / 30));
    this.comparisonSize = WINDOW - this.lastLag - 1;
    this.curve = new Float64Array(this.lastLag + 2);
    this.position = 0;
    this.samples = 0;
    this.gainDb = 0;
    this.gain = 1;
    this.port.onmessage = ({data}) => {
      this.gainDb = data;
      this.gain = 10 ** (data / 20);
    };
  }

  detect() {
    // YIN difference with fixed integration length, then cumulative mean normalization.
    const input = this.detectorInput;
    const curve = this.curve;
    let cumulative = 0;
    curve[0] = 1;
    for (let lag = 1; lag <= this.lastLag + 1; lag++) {
      let difference = 0;
      for (let index = 0; index < this.comparisonSize; index++) {
        const delta = input[index] - input[index + lag];
        difference += delta * delta;
      }
      cumulative += difference;
      curve[lag] = cumulative ? difference * lag / cumulative : 1;
    }

    // The paper's absolute threshold selects a trough. Its fallback always
    // uses the global minimum, so this threshold never rejects a frame.
    let selected = this.firstLag;
    for (let lag = this.firstLag; lag <= this.lastLag; lag++) {
      if (curve[lag] < curve[selected]) selected = lag;
      if (curve[lag] < 0.1 && curve[lag] <= curve[lag - 1] && curve[lag] <= curve[lag + 1]) {
        selected = lag;
        break;
      }
    }
    const left = curve[selected - 1];
    const center = curve[selected];
    const right = curve[selected + 1];
    const curvature = left + right - 2 * center;
    const shift = curvature > 0 ? Math.max(-0.5, Math.min(0.5, (left - right) / (2 * curvature))) : 0;
    const hz = Math.max(30, Math.min(1300, sampleRate / (selected + shift)));
    return {hz, confidence: Math.max(0, 1 - center)};
  }

  analyze(time) {
    let energy = 0;
    let peak = 0;
    for (let index = 0; index < WINDOW; index++) {
      const raw = this.ring[(this.position + index) % WINDOW];
      energy += raw * raw;
      peak = Math.max(peak, Math.abs(raw));
      this.detectorInput[index] = raw * this.gain;
    }
    const rmsDb = 10 * Math.log10(energy / WINDOW);
    const result = rmsDb >= -60 ? this.detect() : {hz: null, confidence: null};
    this.port.postMessage({time, rmsDb, peakDb: 20 * Math.log10(peak), gainDb: this.gainDb, ...result});
  }

  process(inputs) {
    const channel = inputs[0]?.[0];
    if (!channel) return true;
    for (let index = 0; index < channel.length; index++) {
      this.ring[this.position] = channel[index];
      this.position = (this.position + 1) % WINDOW;
      this.samples++;
      if (this.samples >= WINDOW && this.samples % HOP === 0) {
        this.analyze((currentFrame + index + 1) / sampleRate);
      }
    }
    return true;
  }
}

registerProcessor('pano-yin', PanoYin);
