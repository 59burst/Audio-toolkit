const WINDOW = 4096;
const HOP = 1024;

const clamp = (value, low, high) => Math.min(high, Math.max(low, value));

class PitchDetector {
  constructor() {
    this.size = 8192;
    this.real = new Float64Array(this.size);
    this.imag = new Float64Array(this.size);
    this.order = new Uint16Array(this.size);
    this.cos = new Float64Array(this.size / 2);
    this.sin = new Float64Array(this.size / 2);
    this.energy = new Float64Array(4097);
    this.nsdf = new Float64Array(4096);
    for (let i = 1; i < this.size; i++) {
      this.order[i] = (this.order[i >> 1] >> 1) | ((i & 1) * this.size / 2);
    }
    for (let i = 0; i < this.cos.length; i++) {
      const angle = 2 * Math.PI * i / this.size;
      this.cos[i] = Math.cos(angle);
      this.sin[i] = Math.sin(angle);
    }
  }

  fft(inverse) {
    const {size, real, imag, order, cos, sin} = this;
    for (let i = 0; i < size; i++) {
      const j = order[i];
      if (j <= i) continue;
      const r = real[i];
      const t = imag[i];
      real[i] = real[j];
      imag[i] = imag[j];
      real[j] = r;
      imag[j] = t;
    }
    for (let width = 2; width <= size; width *= 2) {
      const half = width / 2;
      const stride = size / width;
      for (let start = 0; start < size; start += width) {
        for (let k = 0; k < half; k++) {
          const a = start + k;
          const b = a + half;
          const c = cos[k * stride];
          const s = (inverse ? 1 : -1) * sin[k * stride];
          const r = c * real[b] - s * imag[b];
          const t = s * real[b] + c * imag[b];
          real[b] = real[a] - r;
          imag[b] = imag[a] - t;
          real[a] += r;
          imag[a] += t;
        }
      }
    }
  }

  analyze(frame, mean, gain, rate) {
    const {real, imag, size, energy, nsdf} = this;
    const length = frame.length;
    real.fill(0);
    imag.fill(0);
    for (let i = 0; i < length; i++) {
      const centered = (frame[i] - mean) * gain;
      real[i] = centered;
      energy[i + 1] = energy[i] + centered * centered;
    }

    // Zero padding gives linear autocorrelation from the inverse power spectrum.
    this.fft(false);
    for (let i = 0; i < size; i++) real[i] = real[i] ** 2 + imag[i] ** 2;
    imag.fill(0);
    this.fft(true);

    // MPM normalizes each lag by the energy of the two overlapping segments.
    const max = Math.min(length - 2, Math.ceil(rate / 30) + 2);
    for (let lag = 0; lag <= max + 1; lag++) {
      const power = energy[length - lag] + energy[length] - energy[lag];
      nsdf[lag] = power > 0 ? (2 * real[lag] / size) / power : 0;
    }
    const peaks = [];
    let crossed = false;
    let best = -1;
    for (let lag = 1; lag <= max + 1; lag++) {
      if (nsdf[lag] <= 0 || lag > max) {
        if (best >= 2) peaks.push(best);
        crossed = true;
        best = -1;
      } else if (crossed && (best < 0 || nsdf[lag] > nsdf[best])) {
        best = lag;
      }
    }
    // Select the first strong positive lobe and refine its maximum.
    const highest = peaks.reduce((top, lag) => Math.max(top, nsdf[lag]), 0);
    let chosen;
    for (const lag of peaks) {
      if (nsdf[lag] < highest * 0.93 || nsdf[lag] < nsdf[lag + 1]) continue;
      const peak = this.interpolate(lag);
      const hz = rate / peak.lag;
      if (hz >= 29.99 && hz <= 1300.1) {
        chosen = peak;
        break;
      }
    }
    if (!chosen) return {hz: null, clarity: highest};

    return {hz: clamp(rate / chosen.lag, 30, 1300), clarity: chosen.clarity, lag: chosen.lag};
  }

  interpolate(lag) {
    const a = this.nsdf[lag - 1];
    const b = this.nsdf[lag];
    const c = this.nsdf[lag + 1];
    const curvature = a - 2 * b + c;
    const delta = curvature ? 0.5 * (a - c) / curvature : 0;
    return {lag: lag + delta, clarity: b - 0.25 * (a - c) * delta};
  }
}

class RawCapture extends AudioWorkletProcessor {
  constructor() {
    super();
    this.ring = new Float32Array(WINDOW);
    this.detectorInput = new Float32Array(WINDOW);
    this.detector = new PitchDetector();
    this.position = 0;
    this.samples = 0;
    this.gainDb = 0;
    this.gain = 1;
    this.port.onmessage = ({data}) => {
      this.gainDb = data;
      this.gain = 10 ** (data / 20);
    };
  }

  analyze(time) {
    let sum = 0;
    let energy = 0;
    let peak = 0;
    for (let index = 0; index < WINDOW; index++) {
      const raw = this.ring[(this.position + index) % WINDOW];
      energy += raw * raw;
      peak = Math.max(peak, Math.abs(raw));
      const sample = raw * this.gain;
      this.detectorInput[index] = sample;
      sum += this.detectorInput[index];
    }
    const rmsDb = 10 * Math.log10(energy / WINDOW);
    const {hz, clarity, lag} = this.detector.analyze(this.detectorInput, sum / WINDOW, 1, sampleRate);
    this.port.postMessage({
      time, rmsDb, peakDb: 20 * Math.log10(peak), gainDb: this.gainDb,
      hz, confidence: clarity, lag: lag ?? null
    });
  }

  process(inputs) {
    const channel = inputs[0]?.[0];
    if (!channel) return true;
    for (let index = 0; index < channel.length; index++) {
      this.ring[this.position] = channel[index];
      this.position = (this.position + 1) % WINDOW;
      this.samples++;
      if (this.samples >= WINDOW && this.samples % HOP === 0) {
        this.analyze((currentFrame + index + 1) / sampleRate);
      }
    }
    return true;
  }
}

registerProcessor('raw-capture', RawCapture);
