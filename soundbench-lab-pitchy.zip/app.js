'use strict';

const ui = Object.fromEntries(Array.from(document.querySelectorAll('[id]'), element => [element.id, element]));
const traceContext = ui.trace.getContext('2d');
const notes = ['C', 'C♯', 'D', 'D♯', 'E', 'F', 'F♯', 'G', 'G♯', 'A', 'A♯', 'B'];
const receipts = [];
const trace = [];
const rows = ['time,rmsDb,confidence,hz,cents,note,gainDb\r\n'];
let worklet;
let peakDb = -Infinity;
let peakExpires = 0;

function formatDb(value) {
  return Number.isFinite(value) ? value.toFixed(1) : '−∞';
}

function meterPosition(db) {
  return Math.max(0, Math.min(100, (db + 90) * 100 / 90));
}

function drawTrace(now) {
  const width = Math.round(ui.trace.clientWidth * devicePixelRatio);
  const height = Math.round(ui.trace.clientHeight * devicePixelRatio);
  if (ui.trace.width !== width) ui.trace.width = width;
  if (ui.trace.height !== height) ui.trace.height = height;

  traceContext.clearRect(0, 0, width, height);
  traceContext.lineWidth = devicePixelRatio;
  traceContext.strokeStyle = '#758293';
  traceContext.beginPath();
  traceContext.moveTo(0, height / 2);
  traceContext.lineTo(width, height / 2);
  traceContext.stroke();

  while (trace.length > 1 && now - trace[1].now > 4000) trace.shift();
  traceContext.strokeStyle = '#aeeef2';
  traceContext.lineWidth = 2 * devicePixelRatio;
  traceContext.beginPath();
  let previousNote;
  for (const point of trace) {
    const x = width * (1 - (now - point.now) / 4000);
    const y = height / 2 - point.cents * height * 0.009;
    if (!point.note) {
      previousNote = undefined;
      continue;
    }
    if (previousNote === point.note) traceContext.lineTo(x, y);
    else traceContext.moveTo(x, y);
    previousNote = point.note;
  }
  traceContext.stroke();
}

function animate(now) {
  while (receipts.length && now - receipts[0] >= 1000) receipts.shift();
  ui.frames.textContent = receipts.length;
  if (now >= peakExpires) {
    peakDb = -Infinity;
    ui.peak.hidden = true;
  }
  drawTrace(now);
  requestAnimationFrame(animate);
}

function receive({ data }) {
  const now = performance.now();
  const { time, rmsDb, peakDb: framePeak, confidence, hz, gainDb } = data;
  receipts.push(now);
  ui.rms.textContent = `${formatDb(rmsDb)} dBFS`;
  ui.clarity.textContent = confidence.toFixed(3);
  ui.level.style.width = `${meterPosition(rmsDb)}%`;
  if (now >= peakExpires || framePeak >= peakDb) {
    peakDb = framePeak;
    peakExpires = now + 850;
    ui.peak.hidden = !Number.isFinite(peakDb);
    ui.peak.style.left = `${meterPosition(peakDb)}%`;
  }

  let cents = '';
  let note = '';
  if (hz !== null) {
    const midi = 69 + 12 * Math.log2(hz / 440);
    const nearest = Math.round(midi);
    cents = 100 * (midi - nearest);
    note = notes[nearest % 12] + (Math.floor(nearest / 12) - 1);
    ui.note.textContent = note;
    ui.frequency.textContent = ui.last.textContent = `${hz.toFixed(2)} Hz`;
    ui.cents.textContent = `${cents >= 0 ? '+' : '−'}${Math.abs(cents).toFixed(1)} ¢`;
    ui.needle.hidden = false;
    ui.needle.style.left = `${50 + cents}%`;
  } else {
    ui.note.textContent = '—';
    ui.frequency.textContent = '— Hz';
    ui.last.textContent = '— Hz';
    ui.cents.textContent = '— ¢';
    ui.needle.hidden = true;
  }
  trace.push({ now, cents, note });
  rows.push([time, rmsDb, confidence ?? '', hz ?? '', cents, note, gainDb].join(',') + '\r\n');
}

ui.mic.addEventListener('click', async () => {
  ui.mic.disabled = true;
  ui.status.textContent = '';
  let context;
  let stream;
  try {
    if (!navigator.mediaDevices?.getUserMedia || !window.AudioContext) {
      throw new Error('Open this page over HTTPS or localhost to use the microphone.');
    }
    context = new AudioContext();
    const resumed = context.resume();
    const capture = navigator.mediaDevices.getUserMedia({
      audio: { echoCancellation: false, noiseSuppression: false, autoGainControl: false }
    }).then(media => stream = media);
    await Promise.all([resumed, capture, context.audioWorklet.addModule('worklet.js')])
      .catch(async error => {
        await context.close();
        capture.then(media => media.getTracks().forEach(track => track.stop()), () => {});
        throw error;
      });
    const source = context.createMediaStreamSource(stream);
    worklet = new AudioWorkletNode(context, 'pitchy-lab', {
      channelCount: 1, channelCountMode: 'explicit', outputChannelCount: [1]
    });
    worklet.port.onmessage = receive;
    worklet.port.postMessage(Number(ui.gain.value));
    // The processor leaves its output silent. Connecting it keeps it scheduled.
    source.connect(worklet).connect(context.destination);
    ui.rate.textContent = `${context.sampleRate} Hz`;
    ui.mic.textContent = 'Mic on';
  } catch (error) {
    stream?.getTracks().forEach(track => track.stop());
    if (context && context.state !== 'closed') context.close().catch(() => {});
    ui.status.textContent = error.message;
    ui.mic.disabled = false;
  }
});

ui.gain.addEventListener('input', () => {
  const gain = Number(ui.gain.value);
  ui.gainValue.textContent = `+${gain} dB`;
  worklet?.port.postMessage(gain);
});
ui.download.addEventListener('click', () => {
  const url = URL.createObjectURL(new Blob(rows, {type: 'text/csv;charset=utf-8'}));
  const link = document.createElement('a');
  link.href = url;
  link.download = 'soundbench-lab-pitchy.csv';
  document.body.append(link);
  link.click();
  link.remove();
  setTimeout(() => URL.revokeObjectURL(url), 30000);
});

requestAnimationFrame(animate);
