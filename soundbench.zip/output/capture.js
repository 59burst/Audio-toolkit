class InputCapture extends AudioWorkletProcessor {
  constructor() {
    super();
    this.ring = new Float32Array(4096);
    this.write = 0;
    this.total = 0;
    this.hop = 0;
    this.enabled = true;
    this.port.onmessage = ({data}) => {
      if (this.enabled === data) return;
      this.enabled = data;
      this.write = this.total = this.hop = 0;
    };
  }

  process(inputs) {
    const samples = inputs[0][0];
    if (!samples || !this.enabled) return true;
    for (const sample of samples) {
      this.ring[this.write] = sample;
      this.write = (this.write + 1) & 4095;
    }
    this.total += samples.length;
    this.hop += samples.length;
    if (this.total >= 4096 && this.hop >= 1024) {
      this.hop = 0;
      const frame = new Float32Array(4096);
      frame.set(this.ring.subarray(this.write));
      frame.set(this.ring.subarray(0, this.write), 4096 - this.write);
      this.port.postMessage(frame, [frame.buffer]);
    }
    return true;
  }
}
registerProcessor('input-capture', InputCapture);
