const VERSION = 22;
const $ = id => document.getElementById(id);
const engine = new AudioEngine();
const noteNames = ['C','C♯','D','D♯','E','F','F♯','G','G♯','A','A♯','B'];
const mod = (n, d) => ((n % d) + d) % d;
const noteName = midi => noteNames[mod(midi, 12)] + (Math.floor(midi / 12) - 1);
const signed = (value, digits = 0) => {
  const number = Number(value.toFixed(digits));
  return (number > 0 ? '+' : '') + number.toFixed(digits).replace('-', '−');
};
const presets = {
  standard: {name:'Standard guitar', notes:[40,45,50,55,59,64]},
  drop: {name:'Drop D guitar', notes:[38,45,50,55,59,64]},
  open: {name:'Open G guitar', notes:[38,43,50,55,59,62]},
  sweet: {name:'Sweetened guitar', notes:[40,45,50,55,59,64], offsets:[-3,-2,0,-1,-4,-2]}
};

const fifth = 1200 * Math.log2(3 / 2);
const pythComma = 12 * fifth - 8400;
const syntonicComma = 1200 * Math.log2(81 / 80);
// Follow the circle of fifths, then normalize each pitch class relative to A.
function temperamentOffsets(kind) {
  const offsets = Array(12).fill(0);
  if (kind === 'equal') return offsets;
  if (kind === 'werck') {
    const chain = [0,7,2,9,4,11,6,1,8,3,10,5];
    for (let i = 1; i < chain.length; i++) {
      const narrowed = [1,2,3,6].includes(i);
      offsets[chain[i]] = offsets[chain[i - 1]] + fifth - 700 - (narrowed ? pythComma / 4 : 0);
    }
  } else {
    const distance = kind === 'meantone' ? fifth - syntonicComma / 4 : fifth;
    for (let step = -3; step <= 8; step++) {
      offsets[mod(7 * step, 12)] = step * (distance - 700);
    }
  }
  return offsets.map(value => value - offsets[9]);
}
const temperaments = Object.fromEntries(['equal','pyth','meantone','werck'].map(name => [name, temperamentOffsets(name)]));

const settings = {theme:'tolex', a4:440, temperament:'equal', preset:'standard', tolerance:5};
try {
  const saved = JSON.parse(localStorage.getItem('soundbench-settings')) || {};
  if (['tweed','tolex'].includes(saved.theme)) settings.theme = saved.theme;
  if (Object.hasOwn(temperaments, saved.temperament)) settings.temperament = saved.temperament;
  if (Object.hasOwn(presets, saved.preset)) settings.preset = saved.preset;
  if (Number.isFinite(saved.a4)) settings.a4 = clamp(saved.a4, 415, 466);
  if ([2,5,10].includes(saved.tolerance)) settings.tolerance = saved.tolerance;
} catch {}

function targetFrequency(midi, guitar = true) {
  const preset = presets[settings.preset];
  const guitarOffset = guitar ? preset.offsets?.[preset.notes.indexOf(midi)] ?? 0 : 0;
  const offset = temperaments[settings.temperament][mod(midi, 12)] + guitarOffset;
  return settings.a4 * 2 ** ((midi - 69) / 12 + offset / 1200);
}

const modules = {
  tuner: {title:'Chromatic Tuner', subtitle:'PITCH DETECTION', gauge:'CENT DEVIATION', mode:'LIVE INPUT', labels:['NOTE','FREQUENCY','DEVIATION'], ticks:['−50','−25','0','+25','+50'], captions:['FLAT','IN TUNE','SHARP']},
  metro: {title:'Metronome', subtitle:'TEMPO & TIME', gauge:'TEMPO SCALE', mode:'AUDIO CLOCK', labels:['TEMPO','BEAT','BEATS / BAR'], ticks:['30','83','135','188','240'], captions:['SLOW','BPM','FAST']},
  tone: {title:'Tone Generator', subtitle:'SIGNAL GENERATOR', gauge:'FREQUENCY SCALE', mode:'OSCILLATOR', labels:['FREQUENCY','NOTE','GAIN'], ticks:['20','112','632','3.6k','20k'], captions:['LOW','HERTZ','HIGH']},
  level: {title:'Level Meter', subtitle:'INPUT MEASUREMENT', gauge:'INPUT LEVEL', mode:'LIVE INPUT', labels:['RMS LEVEL','PEAK HOLD','SPL EST.'], ticks:['−60','−45','−30','−15','0'], captions:['QUIET','DBFS','FULL SCALE']}
};
let active = 'tuner';
let pitch = null;
let lastPitchTime = -Infinity;
let committedNote = null;
let commitWindow = [];
let octaveRun = [];
let liveCandidate = null;
let silenceFrames = 0;
let previousFrameTime = -Infinity;
let lastFrameSample = null;
let frameTimes = [];
let centsHistory = [];
let medianHistory = [];
let lastFrameInTune = false;
let inTuneTime = 0;
let sessionStart;
let sessionLog = [];
let sonificationTimeline = [];
let latestDebug = null;
let graphTime = 0;
let graphPoints = [];
let graphDirty = true;
let latchedNote = null;
const pitchGap = 120;
const silenceFloor = -78;
const graphWindow = 8000;
const pitchY = cents => 88 - clamp(cents, -50, 50) * 1.44;

function drawPitchTrace() {
  graphDirty = false;
  const stride = Math.max(1, Math.ceil(graphPoints.length / 200));
  const sampled = [];
  let start = false;
  for (const [index, point] of graphPoints.entries()) {
    start ||= point.start;
    if (index % stride !== 0 && index !== graphPoints.length - 1) continue;
    sampled.push({...point, start});
    start = false;
  }
  if (sampled.length > 200) sampled.shift();
  const points = sampled.map(point => [
    605 - (graphTime - point.time) * 550 / graphWindow,
    pitchY(point.cents),
    point.start
  ]);
  $('pitchTrace').setAttribute('d', points.map(([x,y,start], index) =>
    (index === 0 || start ? 'M' : 'L') + x.toFixed(2) + ' ' + y.toFixed(2)).join(' '));
  const last = points.at(-1);
  $('pitchPoint').setAttribute('visibility', last ? 'visible' : 'hidden');
  if (last) {
    $('pitchPoint').setAttribute('cx', last[0]);
    $('pitchPoint').setAttribute('cy', last[1]);
  }
}

function resetPitchHistory() {
  centsHistory = [];
  medianHistory = [];
  commitWindow = [];
  octaveRun = [];
  inTuneTime = 0;
}

function resetPitch() {
  pitch = null;
  committedNote = latchedNote = null;
  lastPitchTime = -Infinity;
  liveCandidate = null;
  lastFrameInTune = false;
  resetPitchHistory();
  graphTime = 0;
  graphPoints = [];
  graphDirty = true;
}

function resetDiagnostics() {
  silenceFrames = 0;
  previousFrameTime = -Infinity;
  lastFrameSample = null;
  frameTimes = [];
  liveCandidate = null;
  commitWindow = [];
  octaveRun = [];
  latestDebug = null;
}
let peak = -Infinity;
let toneHz = 440;
let micPending = false;
let audioPending = false;
let levelValue = null;
let weightedValue = null;
let levelTime = -Infinity;
const beatLights = $('beatLights');
const signedUnit = '¢';
const polar = (radius, angle) => {
  const r = angle * Math.PI / 180;
  return [310 + radius * Math.sin(r), 222 - radius * Math.cos(r)];
};
const arc = radius => {
  const [x1,y1] = polar(radius, -66);
  const [x2,y2] = polar(radius, 66);
  return 'M' + x1 + ' ' + y1 + ' A' + radius + ' ' + radius + ' 0 0 1 ' + x2 + ' ' + y2;
};
function angleAt(position) { return -66 + 132 * position; }

function drawScale() {
  const {ticks} = modules[active];
  const scale = [`<path class="rim" d="${arc(175)}"/><path class="arc" d="${arc(175)}"/>`];
  for (let i = 0; i <= 40; i++) {
    const angle = angleAt(i / 40);
    const major = i % 10 === 0;
    const [x1,y1] = polar(major ? 157 : i % 5 === 0 ? 163 : 168, angle);
    const [x2,y2] = polar(184, angle);
    scale.push(`<line class="tick ${major ? 'major' : ''}" x1="${x1}" y1="${y1}" x2="${x2}" y2="${y2}"/>`);
    if (major) {
      const [x,y] = polar(207, angle);
      scale.push(`<text x="${x}" y="${y + 7}">${ticks[i / 10]}</text>`);
    }
  }
  $('dialScale').innerHTML = scale.join('');
}

function updateGauge(position, live = true, marker = null) {
  const value = clamp(position, 0, 1);
  $('needle').style.transform = `rotate(${angleAt(value)}deg)`;
  $('needle').style.opacity = live ? 1 : 0.28;
  const peakMarker = $('peakMarker');
  peakMarker.setAttribute('visibility', marker === null ? 'hidden' : 'visible');
  if (marker !== null) peakMarker.style.transform = `rotate(${angleAt(clamp(marker,0,1))}deg)`;
}

function read(id, value, unit = '') {
  const element = $(id);
  const key = value + '|' + unit;
  if (element.dataset.value === key) return;
  element.dataset.value = key;
  element.textContent = value;
  if (unit) {
    const small = document.createElement('small');
    small.textContent = ' ' + unit;
    element.append(small);
  }
}

function setStatus(text, live) {
  const status = $('status');
  if (status.lastElementChild.textContent !== text) status.lastElementChild.textContent = text;
  status.classList.toggle('live', live);
}

function message(text = '') {
  $('message').textContent = text;
  $('message').hidden = !text;
}

function showModule(name) {
  if (name !== active) {
    engine.stopMetro();
    engine.stopTone();
    closeSonification();
    message();
  }
  if (active !== name) resetDiagnostics();
  active = name;
  debugLine.hidden = name !== 'tuner';
  document.body.dataset.module = name;
  engine.setInputMode(name);
  const metro = name === 'metro';
  for (const id of ['bpmEditor', 'beats']) $(id).hidden = !metro;
  for (const id of ['primary', 'tertiary']) $(id).hidden = metro;
  if (name !== 'level') levelValue = null;
  if (!metro) {
    finishBpmEdit();
    taps = [];
  }
  document.querySelector('.instrument').classList.remove('pitch-tuned');
  $('analogFace').hidden = name !== 'tuner' && name !== 'level';
  $('metroFace').hidden = name !== 'metro';
  $('candidateLine').hidden = name !== 'tuner';
  $('about').hidden = name !== 'tuner';
  $('tunerGraph').hidden = name !== 'tuner';
  const module = modules[name];
  $('moduleTitle').textContent = module.title;
  $('subtitle').textContent = module.subtitle;
  $('gaugeLabel').textContent = module.gauge;
  $('faceMode').textContent = module.mode;
  ['primary','secondary','tertiary'].forEach((id, i) => { $(id + 'Label').textContent = module.labels[i]; });
  ['left','center','right'].forEach((id, i) => { $(id + 'Caption').textContent = module.captions[i]; });
  for (const key of Object.keys(modules)) $(key + 'Controls').hidden = key !== name;
  $('micControls').hidden = name !== 'tuner' && name !== 'level';
  for (const button of document.querySelectorAll('[data-module]')) {
    if (button.dataset.module === name) button.setAttribute('aria-current', 'page');
    else button.removeAttribute('aria-current');
  }
  drawScale();
  updateControls();
  render(performance.now());
}

function refreshSettings() {
  document.documentElement.dataset.theme = settings.theme;
  if (sonificationTimeline.length) drawSonification();
  document.querySelector('meta[name="theme-color"]').content = settings.theme === 'tweed' ? '#cda66c' : '#43301f';
  for (const id of ['a4', 'temperament', 'preset', 'tolerance']) $(id).value = settings[id];
  $('themeToggle').textContent = settings.theme === 'tweed' ? 'Tweed' : 'Brown';
  $('themeToggle').setAttribute('aria-label', 'Cabinet theme: ' + $('themeToggle').textContent);
  $('pitchBand').setAttribute('y', pitchY(settings.tolerance));
  $('pitchBand').setAttribute('height', settings.tolerance * 2.88);
  $('a4Value').value = settings.a4 + ' Hz';
  $('reference').textContent = 'A4 · ' + settings.a4 + ' Hz';
  const temperament = $('temperament').selectedOptions[0].textContent;
  $('temperamentSummary').textContent = temperament + ' temperament';
  const preset = presets[settings.preset];
  $('presetSummary').textContent = preset.name;
  $('presetSummary').title = preset.notes.map(noteName).join(' · ');
  $('presetStrings').replaceChildren(...preset.notes.map(midi => {
    const span = document.createElement('span');
    span.textContent = noteName(midi);
    span.dataset.note = midi;
    return span;
  }));
  $('strings').textContent = preset.notes.map((midi, i) => {
    const offset = preset.offsets?.[i];
    return noteName(midi) + (offset ? ' ' + signed(offset) + '¢' : '');
  }).join(' · ');
}
function saveSettings() {
  try { localStorage.setItem('soundbench-settings', JSON.stringify(settings)); } catch {}
}
$('themeToggle').onclick = () => {
  settings.theme = settings.theme === 'tweed' ? 'tolex' : 'tweed';
  refreshSettings();
  saveSettings();
};
for (const id of ['a4', 'temperament', 'preset', 'tolerance']) {
  $(id).addEventListener('input', () => {
    settings[id] = typeof settings[id] === 'number' ? Number($(id).value) : $(id).value;
    if (id === 'tolerance') {
      inTuneTime = 0;
      lastFrameInTune = false;
    } else {
      resetPitch();
    }
    refreshSettings();
    saveSettings();
  });
}
for (const button of document.querySelectorAll('[data-module]')) {
  button.onclick = () => { if (button.dataset.module !== active) showModule(button.dataset.module); };
}

function updateControls() {
  const mic = Boolean(engine.stream);
  const interrupted = mic && engine.context.state !== 'running';
  const micControls = $('micControls');
  const micAnchor = !mic || interrupted ? document.querySelector('.intro') : debugLine;
  if (micAnchor.nextElementSibling !== micControls) micAnchor.after(micControls);
  $('micButton').textContent = micPending ? 'Waiting for permission…' : interrupted ? 'Resume microphone' : mic ? 'Disable microphone' : 'Enable microphone';
  $('micButton').disabled = micPending;
  $('micHelp').textContent = active === 'level'
    ? 'Turn on the mic to measure levels.'
    : 'Turn on the mic to tune.';
  if (mic) $('micHelp').textContent = interrupted ? 'Tap Resume to restore audio input.' : active === 'level'
    ? 'Live RMS and peak readings from this device.'
    : 'Play one note at a time for a steady reading.';
  $('pilot').setAttribute('aria-pressed', String(engine.timer !== null));
  $('toneButton').textContent = engine.tone ? 'Stop tone' : 'Play tone';
  $('sweepButton').textContent = engine.tone?.sweep ? 'Stop sweep' : 'Start sweep';
  for (const id of ['pilot','toneButton','sweepButton']) $(id).disabled = audioPending;
}
engine.onState = updateControls;
$('micButton').onclick = async () => {
  message();
  if (!engine.stream) {
    await enableMic();
  } else if (engine.context.state !== 'running') {
    try { await engine.wake(); } catch { message('Audio input could not resume. Try again.'); }
    updateControls();
  } else {
    engine.stopMic();
    resetPitch();
    resetDiagnostics();
    peak = -Infinity;
    levelValue = null;
    weightedValue = null;
    levelTime = -Infinity;
    updateControls();
  }
};
async function enableMic() {
  if (micPending) return;
  micPending = true;
  peak = -Infinity;
  levelTime = -Infinity;
  levelValue = null;
  weightedValue = null;
  updateControls();
  try {
    resetPitch();
    sessionStart = performance.now();
    sessionLog = [];
    resetDiagnostics();
    await engine.startMic();
  } catch (error) {
    if (['NotAllowedError','SecurityError'].includes(error.name)) {
      message('Microphone access was blocked. Allow it in your browser’s site settings, then try again.');
    } else if (error.name === 'NotFoundError') {
      message('No microphone was found. Connect one and try again.');
    } else {
      message(error.message || 'The microphone could not be opened. Try again.');
    }
  } finally {
    micPending = false;
    updateControls();
  }
}

const debugLine = $('pitchDebug');

function downloadCsv() {
  const header = 'time,rmsDb,clarity,state,hz,cents,committed note,framesPerSecond,sampleRate,source,peakDb';
  const blob = new Blob([header + '\r\n', sessionLog.map(({fields}) => fields.join(',')).join('\r\n')], {type: 'text/csv;charset=utf-8'});
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = 'soundbench-session.csv';
  document.body.append(link);
  link.click();
  link.remove();
  setTimeout(() => URL.revokeObjectURL(url), 30000);
}
$('downloadCsv').onclick = downloadCsv;
$('levelCsv').onclick = downloadCsv;

function describePitch(hz, clarity) {
  const midiEstimate = Math.round(69 + 12 * Math.log2(hz / settings.a4));
  let closest = Infinity;
  let note;
  for (let midi = midiEstimate - 1; midi <= midiEstimate + 1; midi++) {
    const cents = 1200 * Math.log2(hz / targetFrequency(midi));
    if (Math.abs(cents) < Math.abs(closest)) {
      closest = cents;
      note = midi;
    }
  }

  return {hz, clarity, note, cents: closest};
}

const centsApart = (a, b) => 1200 * Math.abs(Math.log2(a / b));
function isOctave(a, b) {
  return Math.abs(Math.max(a, b) / (2 * Math.min(a, b)) - 1) <= 0.02;
}
function samePitch(a, b) {
  return a.note === b.note && centsApart(a.hz, b.hz) <= 20;
}
function octavePair(a, b) {
  return Math.abs(a.note - b.note) === 12 && isOctave(a.hz, b.hz);
}

function appendAgreeing(window, candidate, agrees) {
  while (window.some(previous => !agrees(previous, candidate))) window.shift();
  window.push(candidate);
}

function considerPitch(candidate, now, hopMs) {
  if (candidate.note === committedNote) {
    commitWindow = [];
    octaveRun = [];
    updatePitchDisplay(candidate, now, hopMs);
    return;
  }
  const octaveChange = pitch && octavePair(candidate, pitch);
  if (octaveChange) {
    commitWindow = [];
    appendAgreeing(octaveRun, candidate, samePitch);
    if (octaveRun.length === 6) updatePitchDisplay(candidate, now, hopMs);
  } else {
    octaveRun = [];
    considerNormalChange(candidate, now, hopMs);
  }
}

function considerNormalChange(candidate, now, hopMs) {
  appendAgreeing(commitWindow, candidate, (a, b) => samePitch(a, b) || octavePair(a, b));
  if (commitWindow.length < 3) return;
  const sides = new Map();
  for (const frame of commitWindow) {
    if (!sides.has(frame.note)) sides.set(frame.note, []);
    sides.get(frame.note).push(frame);
  }
  const mean = frames => frames.reduce((sum, frame) => sum + frame.clarity, 0) / frames.length;
  const winner = [...sides.values()].sort((a, b) => mean(b) - mean(a) || b.length - a.length)[0];
  updatePitchDisplay(winner.at(-1), now, hopMs);
}

function updatePitchDisplay({note, cents: rawCents}, now, hopMs) {
  const changedNote = note !== committedNote;
  if (changedNote) {
    committedNote = note;
    latchedNote = null;
    resetPitchHistory();
  }

  centsHistory.push(rawCents);
  if (centsHistory.length > 3) centsHistory.shift();
  const sorted = [...centsHistory].sort((a,b) => a - b);
  const middle = Math.floor(sorted.length / 2);
  const median = sorted.length === 2 ? (sorted[0] + sorted[1]) / 2 : sorted[middle];
  medianHistory.push(median);
  if (medianHistory.length > 2) medianHistory.shift();
  const cents = medianHistory.reduce((sum, value) => sum + value, 0) / medianHistory.length;
  const target = targetFrequency(committedNote);

  const withinTolerance = note === committedNote && Math.abs(cents) <= settings.tolerance;
  if (withinTolerance) {
    if (lastFrameInTune && !changedNote) inTuneTime += hopMs;
    if (inTuneTime >= 400) latchedNote = committedNote;
  } else if (note === committedNote) {
    inTuneTime = 0;
  }
  lastFrameInTune = withinTolerance;

  const elapsed = now - lastPitchTime;
  const visualGap = elapsed > pitchGap;
  if (graphPoints.length) graphTime += visualGap ? 25 : elapsed;
  graphPoints.push({time: graphTime, cents, start: visualGap || changedNote});
  while (graphPoints[0]?.time < graphTime - graphWindow) graphPoints.shift();
  graphDirty = true;
  lastPitchTime = now;
  pitch = {note: committedNote, hz: target * 2 ** (cents / 1200), cents};
}

engine.onPitch = ({hz, clarity, rmsDb, frameSample}) => {
  const now = performance.now();
  const rate = engine.context.sampleRate;
  const hopMs = 1024000 / rate;
  if (lastFrameSample === null || frameSample - lastFrameSample !== 1024) {
    silenceFrames = 0;
    frameTimes = [];
    commitWindow = [];
    octaveRun = [];
    lastFrameInTune = false;
  }
  previousFrameTime = now;
  lastFrameSample = frameSample;
  const frameTime = frameSample * 1000 / rate;
  frameTimes.push(frameTime);
  while (frameTimes[0] < frameTime - 1000) frameTimes.shift();
  const span = frameTime - frameTimes[0];
  const fps = span > 0 ? (frameTimes.length - 1) * 1000 / span : 0;
  silenceFrames = rmsDb < silenceFloor ? silenceFrames + 1 : 0;
  const silent = (silenceFrames - 1) * hopMs >= 2000;
  const candidate = hz !== null && clarity >= 0.75 ? describePitch(hz, clarity) : null;
  liveCandidate = silent ? null : candidate;

  if (silent) {
    if (pitch || commitWindow.length) resetPitch();
  } else if (candidate) {
    considerPitch(candidate, now, hopMs);
  } else {
    commitWindow = [];
    octaveRun = [];
    lastFrameInTune = false;
    inTuneTime = 0;
  }
  if (candidate?.note !== committedNote) {
    lastFrameInTune = false;
    inTuneTime = 0;
  }
  const state = silent ? 'silence' : pitch ? (candidate?.note === committedNote ? 'tracking' : 'hold') : 'acquiring';
  latestDebug = {rmsDb, clarity, hz, rate, fps};
  sessionLog.push({fields: [
    (now - sessionStart).toFixed(2),
    rmsDb.toFixed(2), clarity.toFixed(4), state,
    hz?.toFixed(3) ?? '', candidate?.cents.toFixed(3) ?? '',
    committedNote === null ? '' : noteName(committedNote), fps.toFixed(1), rate, 'tuner', ''
  ]});
};

engine.onLevel = ({rmsDb, frameSample}) => {
  levelValue = rmsDb;
  peak = Math.max(peak, rmsDb);
  sessionLog.push({frameSample, fields: [
    (performance.now() - sessionStart).toFixed(2), rmsDb.toFixed(2), '', 'measuring',
    '', '', '', '', engine.context.sampleRate, 'level', peak.toFixed(2)
  ]});
};

function openSonification() {
  const rows = sessionLog.filter(({fields}) => fields[9] === 'level');
  const firstSample = rows[0]?.frameSample;
  sonificationTimeline = rows.map(({frameSample, fields}, index) => {
    const rate = Number(fields[8]);
    const nextSample = rows[index + 1]?.frameSample;
    const time = (frameSample - firstSample) / rate;
    const gapAfter = nextSample !== undefined && nextSample - frameSample !== 1024;
    return {time, end: time + 1024 / rate, rmsDb: Number(fields[1]), gapAfter};
  });
  document.body.classList.add('show-sonification');
  engine.setInputMode('sonification');
  $('sonification').hidden = false;
  drawSonification();
  $('closeSonification').focus({preventScroll:true});
  $('sonification').scrollIntoView({block:'nearest'});
}

function closeSonification() {
  if ($('sonification').hidden) return;
  document.body.classList.remove('show-sonification');
  if (active === 'level') engine.setInputMode('level');
  sonificationTimeline = [];
  $('sonification').hidden = true;
}

function drawSonification() {
  const canvas = $('levelCurve');
  const ctx = canvas.getContext('2d');
  const duration = sonificationTimeline.at(-1)?.end ?? 0;
  $('sonificationDuration').textContent = duration.toFixed(2) + ' s';
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  canvas.setAttribute('aria-label', duration ? 'Recorded RMS level over time' : 'No Level Meter data in this session');
  if (!duration) return;
  ctx.strokeStyle = getComputedStyle(canvas).color;
  ctx.lineWidth = 2;
  ctx.beginPath();
  let startSegment = true;
  for (const {time, end, rmsDb, gapAfter} of sonificationTimeline) {
    const y = 1 + clamp(-rmsDb / 100, 0, 1) * (canvas.height - 2);
    const x = time / duration * canvas.width;
    if (startSegment) ctx.moveTo(x, y);
    else ctx.lineTo(x, y);
    ctx.lineTo(end / duration * canvas.width, y);
    startSegment = gapAfter;
  }
  ctx.stroke();
}

$('viewSonification').onclick = openSonification;
$('closeSonification').onclick = () => {
  closeSonification();
  $('viewSonification').focus({preventScroll:true});
};
function bpm() { return Number($('bpm').value); }
function barBeats() { return Number($('beats').value); }
function refreshMetro() {
  read('bpmDisplay', bpm(), 'BPM');
  const weight = $('pendulumWeight');
  weight.style.bottom = (42 + (240 - bpm()) * 58 / 210) + 'px';
  weight.setAttribute('aria-valuenow', bpm());
  if (beatLights.children.length !== barBeats()) {
    beatLights.replaceChildren(...Array.from({length:barBeats()}, () => document.createElement('span')));
  }
}
$('bpm').oninput = refreshMetro;
$('beats').onchange = refreshMetro;
function setBpm(value) {
  $('bpm').value = clamp(Math.round(value), 30, 240);
  refreshMetro();
}
$('tempoDown').onclick = () => setBpm(bpm() - 1);
$('tempoUp').onclick = () => setBpm(bpm() + 1);
const bpmEntry = $('bpmEntry');
$('bpmDisplay').onclick = () => {
  bpmEntry.value = bpm();
  bpmEntry.hidden = false;
  $('bpmUnit').hidden = false;
  $('bpmDisplay').hidden = true;
  bpmEntry.focus();
  bpmEntry.select();
};
bpmEntry.oninput = () => {
  if (bpmEntry.validity.valid && Number.isFinite(bpmEntry.valueAsNumber)) setBpm(bpmEntry.valueAsNumber);
};
function finishBpmEdit() {
  if (bpmEntry.hidden) return;
  if (Number.isFinite(bpmEntry.valueAsNumber)) setBpm(bpmEntry.valueAsNumber);
  bpmEntry.hidden = true;
  $('bpmUnit').hidden = true;
  $('bpmDisplay').hidden = false;
}
bpmEntry.onblur = finishBpmEdit;
bpmEntry.onkeydown = event => {
  if (event.key === 'Enter') bpmEntry.blur();
};

const weight = $('pendulumWeight');
const metroFace = $('metroFace');
const tapPad = $('tapPad');
let pendulumTouch = null;
metroFace.onpointerdown = event => {
  if (event.button !== 0 || pendulumTouch || $('pilot').contains(event.target) || tapPad.contains(event.target)) return;
  metroFace.setPointerCapture(event.pointerId);
  pendulumTouch = {
    id: event.pointerId, x: event.clientX, y: event.clientY, bpm: bpm(),
    time: performance.now(), weight: event.target === weight, moved: false
  };
};
function movePendulum(event) {
  const touch = pendulumTouch;
  if (touch?.id !== event.pointerId) return;
  const deltaY = event.clientY - touch.y;
  touch.moved ||= Math.hypot(event.clientX - touch.x, deltaY) >= 6;
  if (touch.moved && touch.weight) setBpm(touch.bpm + deltaY * 210 / 58);
}
metroFace.onpointermove = movePendulum;
metroFace.onpointerup = event => {
  if (pendulumTouch?.id !== event.pointerId) return;
  movePendulum(event);
  if (!pendulumTouch.moved && performance.now() - pendulumTouch.time <= 300) recordTempoTap();
  pendulumTouch = null;
};
metroFace.onlostpointercapture = () => { pendulumTouch = null; };
weight.onkeydown = event => {
  const values = {ArrowUp: bpm() + 1, ArrowRight: bpm() + 1, ArrowDown: bpm() - 1,
    ArrowLeft: bpm() - 1, Home: 30, End: 240};
  if (!Object.hasOwn(values, event.key)) return;
  event.preventDefault();
  setBpm(values[event.key]);
};
let taps = [];
let tapFlashTimer;
tapPad.onclick = recordTempoTap;
function recordTempoTap() {
  tapPad.classList.add('flash');
  clearTimeout(tapFlashTimer);
  tapFlashTimer = setTimeout(() => tapPad.classList.remove('flash'), 110);
  const now = performance.now();
  if (taps.length && now - taps.at(-1) > 2300) taps = [];
  if (taps.length && now - taps.at(-1) < 200) return;
  taps.push(now);
  if (taps.length > 6) taps.shift();
  if (taps.length > 1) {
    setBpm(60000 * (taps.length - 1) / (now - taps[0]));
  }
}

async function startOutput(module, start) {
  if (audioPending) return;
  audioPending = true;
  updateControls();
  message();
  try {
    await engine.wake();
    if (active === module) start();
  } catch (error) {
    message(error.message || 'Audio output could not start.');
  } finally {
    audioPending = false;
    updateControls();
  }
}

$('pilot').onclick = () => {
  if (engine.timer !== null) {
    engine.stopMetro();
    updateControls();
  } else {
    startOutput('metro', () => engine.startMetro(bpm, barBeats));
  }
};

const tonePosition = hz => Math.log(hz / 20) / Math.log(1000);
const fromTonePosition = position => 20 * 1000 ** position;
const toneWaveform = () => $('waveform').querySelector('input:checked').value;
const toneGain = () => Number($('gain').value) / 100 * 0.5;
function setTone(hz) {
  toneHz = Math.round(clamp(hz,20,20000) * 10) / 10;
  $('frequency').value = toneHz.toFixed(1);
  $('frequencyRange').value = Math.round(tonePosition(toneHz) * 10000);
  refreshTone();
}
function refreshTone() {
  $('gainValue').value = $('gain').value + '%';
  engine.updateTone(toneWaveform(), toneHz, toneGain());
}
$('frequency').onchange = () => setTone(Number.isFinite($('frequency').valueAsNumber) ? $('frequency').valueAsNumber : toneHz);
$('frequencyRange').oninput = () => setTone(fromTonePosition(Number($('frequencyRange').value) / 10000));
$('lowerWhole').onclick = () => setTone(toneHz - 1);
$('raiseWhole').onclick = () => setTone(toneHz + 1);
$('lower').onclick = () => setTone(toneHz - 0.1);
$('raise').onclick = () => setTone(toneHz + 0.1);
$('gain').oninput = refreshTone;
$('waveform').onchange = refreshTone;
for (const midi of [60,62,64,65,67,69,71]) {
  const button = document.createElement('button');
  button.className = 'button';
  button.type = 'button';
  button.textContent = noteName(midi);
  button.onclick = () => setTone(targetFrequency(midi, false));
  $('noteButtons').append(button);
}
$('toneButton').onclick = () => {
  if (engine.tone) {
    engine.stopTone();
    updateControls();
  } else {
    startOutput('tone', () => engine.startTone(toneWaveform(), toneHz, toneGain()));
  }
};
$('sweepButton').onclick = () => {
  if (engine.tone?.sweep) {
    engine.stopTone();
    updateControls();
    return;
  }
  const fields = ['sweepStart','sweepEnd','sweepDuration'].map($);
  const invalid = fields.find(field => !Number.isFinite(field.valueAsNumber) || !field.validity.valid);
  if (invalid) {
    message('Enter frequencies from 20 to 20,000 Hz and a duration from 0.1 to 120 seconds.');
    invalid.focus();
    return;
  }
  const [from,to,duration] = fields.map(field => field.valueAsNumber);
  startOutput('tone', () => engine.startTone(toneWaveform(), toneHz, toneGain(), {from,to,duration}));
};
$('offset').oninput = () => { $('offsetValue').value = signed(Number($('offset').value)) + ' dB'; };
$('resetPeak').onclick = () => { peak = -Infinity; };

function render(now) {
  if (active === 'tuner') {
    const live = Boolean(engine.stream && engine.context.state === 'running');
    const age = now - lastPitchTime;
    const tracking = live && pitch && age <= pitchGap;
    const inTune = pitch && latchedNote === pitch.note;
    const display = document.querySelector('.instrument');
    display.classList.toggle('pitch-tuned', Boolean(inTune));
    read('primary', pitch ? noteNames[mod(pitch.note, 12)] : '—');
    updateGauge(pitch ? (pitch.cents + 50) / 100 : 0.5, Boolean(pitch));
    const candidate = live && now - previousFrameTime <= pitchGap ? liveCandidate : null;
    read('candidateLine', candidate ? `Live · ${noteNames[mod(candidate.note, 12)]} · ${candidate.hz.toFixed(1)} Hz` : 'Live · —');
    read('secondary', pitch ? pitch.hz.toFixed(1) : '—', 'Hz');
    read('tertiary', pitch ? signed(pitch.cents, 1) : '—', signedUnit);
    for (const string of $('presetStrings').children) {
      const matched = Boolean(pitch && Number(string.dataset.note) === pitch.note);
      const checked = matched && inTune;
      string.classList.toggle('matched', matched);
      string.classList.toggle('checked', Boolean(checked));
      const label = noteName(Number(string.dataset.note)) + (checked ? ' ✓' : '');
      if (string.textContent !== label) string.textContent = label;
    }
    setStatus(inTune ? '✓ In tune' : tracking ? 'Tracking' : live ? (pitch ? 'Holding' : 'Listening') : micPending ? 'Connecting' : engine.stream ? 'Mic paused' : 'Mic off', Boolean(inTune || live));
  } else if (active === 'metro') {
    const running = engine.timer !== null && engine.context.state === 'running';
    const audioTime = running ? engine.playbackTime() : 0;
    const beat = running ? engine.events.findLast(event => event.time <= audioTime) : null;
    const beatIndex = beat ? beat.beat % barBeats() : -1;
    Array.from(beatLights.children).forEach((light, i) => light.classList.toggle('on', i === beatIndex));
    beatLights.setAttribute('aria-label', beatIndex >= 0 ? 'Beat ' + (beatIndex + 1) : 'Beat indicator');
    const elapsed = beat ? audioTime - beat.time : Infinity;
    const swing = beat ? Math.cos(Math.PI * Math.min(1, elapsed / beat.period)) : 0;
    $('pendulumArm').style.transform = `rotate(${beat ? swing * beat.swingSide * 20 : 0}deg)`;
    $('pilot').classList.toggle('running', running);
    $('pilot').classList.toggle('flash', elapsed < 0.12);
    $('pilot').classList.toggle('downbeat', elapsed < 0.16 && Boolean(beat?.accent));
    read('secondary', beatIndex >= 0 ? beatIndex + 1 : '—');
    setStatus(running ? 'Running' : engine.timer !== null ? 'Paused' : 'Stopped', running);
  } else if (active === 'tone') {
    const tone = engine.tone;
    const running = Boolean(tone && engine.context.state === 'running');
    let hz = toneHz;
    if (tone?.sweep) {
      const {from,to,duration} = tone.sweep;
      const position = clamp((engine.playbackTime() - tone.start) / duration, 0, 1);
      hz = from * (to / from) ** position;
    }
    read('primary', hz.toFixed(1), 'Hz');
    read('secondary', noteName(Math.round(69 + 12 * Math.log2(hz / settings.a4))));
    read('tertiary', $('gain').value, '%');
    setStatus(running ? tone.sweep ? 'Sweeping' : 'Playing' : tone ? 'Paused' : 'Stopped', running);
  } else if (!$('sonification').hidden) {
    setStatus('Sonification', false);
  } else {
    const live = Boolean(engine.stream && engine.context.state === 'running');
    if (live && now - levelTime >= 40) {
      levelTime = now;
      weightedValue = $('weighting').checked ? engine.db(true) : levelValue;
    }
    const show = live && levelValue !== null;
    const display = value => Number.isFinite(value) && value > -100 ? value.toFixed(1).replace('-', '−') : '−∞';
    // The nominal reference maps 0 dBFS to 100 dB SPL before calibration.
    const estimate = weightedValue + 100 + Number($('offset').value);
    updateGauge(show ? (levelValue + 60) / 60 : 0, show,
      show && Number.isFinite(peak) ? (peak + 60) / 60 : null);
    read('primary', show ? display(levelValue) : '—', 'dBFS');
    read('secondary', show ? display(peak) : '—', 'dBFS');
    read('tertiary', show ? weightedValue > -100 ? estimate.toFixed(1) : '−∞' : '—', $('weighting').checked ? 'dBA' : 'dB');
    setStatus(live ? 'Measuring' : micPending ? 'Connecting' : engine.stream ? 'Mic paused' : 'Mic off', live);
  }
}

function frame(now) {
  if (active === 'tuner') {
    if (graphDirty) drawPitchTrace();
    const info = latestDebug;
    const text = info
      ? `${info.rmsDb.toFixed(1)} dBFS · ${info.fps.toFixed(1)} fps · ${info.rate} Hz SR · NSDF ${info.clarity.toFixed(2)} · ${info.hz?.toFixed(1) ?? '—'} Hz`
      : `— dBFS · — fps · ${engine.context?.sampleRate ?? '—'} Hz SR · NSDF — · — Hz`;
    read('debugText', text);
    $('rmsBar').value = clamp(info?.rmsDb ?? -90, -90, 0);
  }
  render(now);
  requestAnimationFrame(frame);
}

refreshSettings();
refreshMetro();
setTone(440);
showModule('tuner');
requestAnimationFrame(frame);
$('appVersion').textContent = '· Version ' + VERSION;

const launchSplash = $('launchSplash');
function dismissLaunchSplash() {
  launchSplash.hidden = true;
}
function showLaunchSplash() {
  try {
    if (sessionStorage.getItem('soundbench-launched')) return;
    sessionStorage.setItem('soundbench-launched', '1');
  } catch {}
  launchSplash.addEventListener('animationend', dismissLaunchSplash, {once:true});
  launchSplash.hidden = false;
}
showLaunchSplash();

document.addEventListener('visibilitychange', () => {
  void engine.updateScreenWakeLock();
  if (document.hidden) dismissLaunchSplash();
});
window.addEventListener('pagehide', () => {
  dismissLaunchSplash();
  closeSonification();
  engine.stopMic();
  resetPitch();
  resetDiagnostics();
  engine.stopMetro();
  engine.stopTone();
  updateControls();
});
if ('serviceWorker' in navigator) {
  let hadController = Boolean(navigator.serviceWorker.controller);
  let reloading = false;
  navigator.serviceWorker.addEventListener('controllerchange', () => {
    if (hadController && !reloading) {
      reloading = true;
      window.location.reload();
    }
    hadController = Boolean(navigator.serviceWorker.controller);
  });
  navigator.serviceWorker.register('sw.js').catch(error => console.warn('Offline setup failed:', error));
}
