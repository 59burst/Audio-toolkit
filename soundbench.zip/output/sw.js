const CACHE = 'soundbench-shell-v13';
const SHELL = ['index.html', 'style.css', 'engine.js', 'app.js', 'capture.js', 'manifest.json', 'icon.svg', 'tweed-texture.webp'];
const shellUrls = new Set(SHELL.map(path => new URL(path, self.registration.scope).href));
const indexUrl = new URL('index.html', self.registration.scope).href;

self.addEventListener('install', event => {
  event.waitUntil(caches.open(CACHE).then(cache => cache.addAll([...shellUrls].map(url => new Request(url, {cache: 'reload'})))));
});

self.addEventListener('activate', event => {
  event.waitUntil((async () => {
    const names = await caches.keys();
    await Promise.all(names.filter(name => name.startsWith('soundbench-shell-') && name !== CACHE)
      .map(name => caches.delete(name)));
    await self.clients.claim();
  })());
});

self.addEventListener('fetch', event => {
  const {request} = event;
  if (request.method !== 'GET') return;
  const url = new URL(request.url);
  const path = url.origin + url.pathname;
  const home = request.mode === 'navigate' && (path === self.registration.scope || path === indexUrl);
  if (!home && !shellUrls.has(path)) return;
  event.respondWith((async () => {
    const cache = await caches.open(CACHE);
    return (await cache.match(home ? indexUrl : path)) || fetch(request);
  })());
});
