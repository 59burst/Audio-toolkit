const WINDOW = 4096;
const HOP = 1024;
const clamp = (value, low, high) => Math.min(high, Math.max(low, value));

class PitchDetector {
  constructor() {
    this.size = 8192;
    this.reset();
    this.real = new Float64Array(this.size);
    this.imag = new Float64Array(this.size);
    this.order = new Uint16Array(this.size);
    this.cos = new Float64Array(this.size / 2);
    this.sin = new Float64Array(this.size / 2);
    this.energy = new Float64Array(4097);
    this.nsdf = new Float64Array(4096);
    for (let i = 1; i < this.size; i++) {
      this.order[i] = (this.order[i >> 1] >> 1) | ((i & 1) * this.size / 2);
    }
    for (let i = 0; i < this.cos.length; i++) {
      const angle = 2 * Math.PI * i / this.size;
      this.cos[i] = Math.cos(angle);
      this.sin[i] = Math.sin(angle);
    }
  }

  fft(inverse) {
    const {size, real, imag, order, cos, sin} = this;
    for (let i = 0; i < size; i++) {
      const j = order[i];
      if (j <= i) continue;
      const r = real[i];
      const t = imag[i];
      real[i] = real[j];
      imag[i] = imag[j];
      real[j] = r;
      imag[j] = t;
    }
    for (let width = 2; width <= size; width *= 2) {
      const half = width / 2;
      const stride = size / width;
      for (let start = 0; start < size; start += width) {
        for (let k = 0; k < half; k++) {
          const a = start + k;
          const b = a + half;
          const c = cos[k * stride];
          const s = (inverse ? 1 : -1) * sin[k * stride];
          const r = c * real[b] - s * imag[b];
          const t = s * real[b] + c * imag[b];
          real[b] = real[a] - r;
          imag[b] = imag[a] - t;
          real[a] += r;
          imag[a] += t;
        }
      }
    }
  }

  reset() {
    this.tracking = false;
    this.misses = 0;
    this.level = null;
  }

  detect(frame, rate, octave) {
    let sum = 0;
    let power = 0;
    for (const sample of frame) {
      sum += sample;
      power += sample * sample;
    }
    const rms = Math.sqrt(power / frame.length);
    const rmsDb = 20 * Math.log10(Math.max(rms, 1e-10));
    this.level ??= rms;
    const timeConstant = rms > this.level ? 0.050 : 0.300;
    this.level += (rms - this.level) * -Math.expm1(-HOP / (rate * timeConstant));
    const gain = clamp(10 ** (-28 / 20) / Math.max(this.level, 1e-10), 1, 10 ** (24 / 20));
    let {hz, clarity} = power > 0
      ? this.analyze(frame, sum / frame.length, gain, rate, octave)
      : {hz: null, clarity: 0};
    if (rmsDb < (this.tracking ? -62 : -52) || clarity < (this.tracking ? 0.45 : 0.60)) hz = null;
    if (hz !== null) {
      this.tracking = true;
      this.misses = 0;
    } else if (this.tracking && ++this.misses >= 12) {
      this.tracking = false;
    }
    return {hz, clarity, rmsDb};
  }

  analyze(frame, mean, gain, rate, octave) {
    const {real, imag, size, energy, nsdf} = this;
    const length = frame.length;
    real.fill(0);
    imag.fill(0);
    for (let i = 0; i < length; i++) {
      const centered = (frame[i] - mean) * gain;
      real[i] = centered;
      energy[i + 1] = energy[i] + centered * centered;
    }

    // Zero padding gives linear autocorrelation from the inverse power spectrum.
    this.fft(false);
    for (let i = 0; i < size; i++) real[i] = real[i] ** 2 + imag[i] ** 2;
    imag.fill(0);
    this.fft(true);

    // MPM normalizes each lag by the energy of the two overlapping segments.
    const max = Math.min(length - 2, Math.ceil(rate / 30) + 2);
    for (let lag = 0; lag <= max + 1; lag++) {
      const power = energy[length - lag] + energy[length] - energy[lag];
      nsdf[lag] = power > 0 ? (2 * real[lag] / size) / power : 0;
    }
    const peaks = [];
    let crossed = false;
    let best = -1;
    for (let lag = 1; lag <= max + 1; lag++) {
      if (nsdf[lag] <= 0 || lag > max) {
        if (best >= 2) peaks.push(best);
        crossed = true;
        best = -1;
      } else if (crossed && (best < 0 || nsdf[lag] > nsdf[best])) {
        best = lag;
      }
    }
    // Select the first strong positive lobe and refine its maximum.
    const highest = peaks.reduce((top, lag) => Math.max(top, nsdf[lag]), 0);
    let chosen;
    for (const lag of peaks) {
      if (nsdf[lag] < highest * 0.93 || nsdf[lag] < nsdf[lag + 1]) continue;
      const peak = this.interpolate(lag);
      const hz = rate / peak.lag;
      if (hz >= 29.99 && hz <= 1300.1) {
        chosen = peak;
        break;
      }
    }
    if (!chosen) return {hz: null, clarity: highest};

    // A lower octave is eligible only near twice the selected period.
    if (octave?.notes.length) {
      for (const lag of peaks) {
        if (Math.abs(lag - 2 * chosen.lag) > Math.max(1, 0.02 * chosen.lag)) continue;
        if (nsdf[lag] < nsdf[lag - 1] || nsdf[lag] < nsdf[lag + 1]) continue;
        const lower = this.interpolate(lag);
        const hz = rate / lower.lag;
        if (hz < 30 || lower.clarity < 0.92 * chosen.clarity) continue;
        const midiEstimate = Math.round(69 + 12 * Math.log2(hz / octave.a4));
        let closest = Infinity;
        let note;
        for (let midi = midiEstimate - 1; midi <= midiEstimate + 1; midi++) {
          const distance = Math.abs(Math.log2(hz / octave.frequencies[midi]));
          if (distance < closest) {
            closest = distance;
            note = midi;
          }
        }
        if (octave.notes.includes(note)) {
          return {hz, clarity: lower.clarity};
        }
      }
    }
    return {hz: clamp(rate / chosen.lag, 30, 1300), clarity: chosen.clarity};
  }

  interpolate(lag) {
    const a = this.nsdf[lag - 1];
    const b = this.nsdf[lag];
    const c = this.nsdf[lag + 1];
    const curvature = a - 2 * b + c;
    const delta = curvature ? 0.5 * (a - c) / curvature : 0;
    return {lag: lag + delta, clarity: b - 0.25 * (a - c) * delta};
  }
}

class InputCapture extends AudioWorkletProcessor {
  constructor() {
    super();
    this.detector = new PitchDetector();
    this.ring = new Float32Array(WINDOW);
    this.frame = new Float32Array(WINDOW);
    this.write = 0;
    this.untilFrame = WINDOW;
    this.enabled = true;
    this.port.onmessage = ({data}) => {
      if ('octave' in data) this.octave = data.octave;
      if (!('enabled' in data) || this.enabled === data.enabled) return;
      this.enabled = data.enabled;
      this.write = 0;
      this.untilFrame = WINDOW;
      this.detector.reset();
    };
  }

  process(inputs) {
    const samples = inputs[0][0];
    if (!samples || !this.enabled) return true;
    for (const sample of samples) {
      this.ring[this.write] = sample;
      this.write = (this.write + 1) % WINDOW;
      if (--this.untilFrame) continue;
      this.untilFrame = HOP;
      this.frame.set(this.ring.subarray(this.write));
      this.frame.set(this.ring.subarray(0, this.write), WINDOW - this.write);
      this.port.postMessage(this.detector.detect(this.frame, sampleRate, this.octave));
    }
    return true;
  }
}

registerProcessor('input-capture', InputCapture);
