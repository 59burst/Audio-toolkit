# Soundbench

A static, offline-capable musician’s toolkit with a chromatic tuner, metronome, tone generator, and level meter. The JavaScript and styles ship as plain source. Microphone audio stays on the device.

## Run locally

From this directory, run:

```sh
python3 -m http.server 8000
```

Open http://localhost:8000 in desktop Chrome. Use the Enable microphone button in Tuner or Level to grant permission. Opening the HTML from disk does not provide the secure context needed by the microphone and service worker.

## Deploy and install

Upload the files alongside this README to the same directory on any HTTPS static host. Subdirectories work. Open the deployed URL once online to cache the app shell. On iPhone Safari (iOS 17+), open the Share menu and choose **Add to Home Screen**. On desktop Chrome, use the browser’s install control when available. Installed or in the browser, microphone access is subject to site permission. Audio starts from a button tap.

When releasing updated files, increment the cache version in `sw.js`. Once all copies of the old app are closed, the next visit will use the updated shell.

## Measurement and tuning

The tuner uses the McLeod Pitch Method, with FFT-based autocorrelation, normalized square difference peak selection, and parabolic interpolation. Pitch detection runs in an AudioWorklet. Its input goes through a 70 Hz high-pass filter and up to 24 dB of automatic gain before detection. A separate acquire gate and a less restrictive tracking gate help the tuner follow quiet decays. The level meter uses its own unboosted input path.

The graph shows the most recent eight seconds of tracked pitch. It pauses when pitch is lost, and the last note, frequency, and deviation stay visible and dim after 2.5 seconds. Response sets the moving average to one to four frames after a three-frame median. The trace, cents, and frequency use the same smoothing. In Settings, choose a tolerance of ±2, ±5, or ±10 cents. Holding a note within that band for about 0.4 seconds latches the in-tune indicator until another note is committed. Guitar preset strings are displayed on the tuner, and Sweetened applies the listed per-string offsets. The tuner remains chromatic with every preset.

Long-press the tuner status to see frame RMS, NSDF clarity, the gate state, and the audio sample rate. Settings → Download CSV exports the current microphone session’s pitch diagnostics. Time is in milliseconds from the microphone start request.

Use the theme button beside Settings to switch between Blue Analog and Orange Digital.

The level meter holds the highest RMS reading until reset. The estimated SPL starts with a nominal 100 dB reference for 0 dBFS. Use a known acoustic reference and adjust Calibration offset to match it. The optional A-weighting applies to the SPL estimate only. Estimates depend on microphone response, input gain, and system processing.

Switching modules stops any running tone or metronome. An enabled microphone remains available between Tuner and Level and can be disabled from either. Closing the page releases the microphone.
