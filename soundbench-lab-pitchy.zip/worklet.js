import { PitchDetector } from "./pitchy.js";

const WINDOW = 4096;
const HOP = 1024;

class PitchyLab extends AudioWorkletProcessor {
  constructor() {
    super();
    this.ring = new Float32Array(WINDOW);
    this.detectorInput = new Float64Array(WINDOW);
    this.detector = PitchDetector.forFloat64Array(WINDOW);
    this.position = 0;
    this.samples = 0;
    this.gainDb = 0;
    this.gain = 1;
    this.port.onmessage = ({data}) => {
      this.gainDb = data;
      this.gain = 10 ** (data / 20);
    };
  }

  analyze(time) {
    let energy = 0;
    let peak = 0;
    for (let index = 0; index < WINDOW; index++) {
      const raw = this.ring[(this.position + index) % WINDOW];
      energy += raw * raw;
      peak = Math.max(peak, Math.abs(raw));
      this.detectorInput[index] = raw * this.gain;
    }
    const rmsDb = 10 * Math.log10(energy / WINDOW);
    const [hz, confidence] = this.detector.findPitch(this.detectorInput, sampleRate);
    this.port.postMessage({
      time, rmsDb, peakDb: 20 * Math.log10(peak), gainDb: this.gainDb,
      hz: hz || null, confidence
    });
  }

  process(inputs) {
    const channel = inputs[0]?.[0];
    if (!channel) return true;
    for (let index = 0; index < channel.length; index++) {
      this.ring[this.position] = channel[index];
      this.position = (this.position + 1) % WINDOW;
      this.samples++;
      if (this.samples >= WINDOW && this.samples % HOP === 0) {
        this.analyze((currentFrame + index + 1) / sampleRate);
      }
    }
    return true;
  }
}

registerProcessor('pitchy-lab', PitchyLab);
