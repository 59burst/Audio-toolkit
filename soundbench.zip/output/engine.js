const clamp = (value, low, high) => Math.min(high, Math.max(low, value));

class PitchDetector {
  constructor() {
    this.size = 8192;
    this.reset();
    this.real = new Float64Array(this.size);
    this.imag = new Float64Array(this.size);
    this.order = new Uint16Array(this.size);
    this.cos = new Float64Array(this.size / 2);
    this.sin = new Float64Array(this.size / 2);
    this.energy = new Float64Array(4097);
    this.nsdf = new Float64Array(4096);
    for (let i = 1; i < this.size; i++) {
      this.order[i] = (this.order[i >> 1] >> 1) | ((i & 1) * this.size / 2);
    }
    for (let i = 0; i < this.cos.length; i++) {
      const angle = 2 * Math.PI * i / this.size;
      this.cos[i] = Math.cos(angle);
      this.sin[i] = Math.sin(angle);
    }
  }

  fft(inverse) {
    const {size, real, imag, order, cos, sin} = this;
    for (let i = 0; i < size; i++) {
      const j = order[i];
      if (j <= i) continue;
      [real[i], real[j]] = [real[j], real[i]];
      [imag[i], imag[j]] = [imag[j], imag[i]];
    }
    for (let width = 2; width <= size; width *= 2) {
      const half = width / 2;
      const stride = size / width;
      for (let start = 0; start < size; start += width) {
        for (let k = 0; k < half; k++) {
          const a = start + k;
          const b = a + half;
          const c = cos[k * stride];
          const s = (inverse ? 1 : -1) * sin[k * stride];
          const r = c * real[b] - s * imag[b];
          const t = s * real[b] + c * imag[b];
          real[b] = real[a] - r;
          imag[b] = imag[a] - t;
          real[a] += r;
          imag[a] += t;
        }
      }
    }
  }

  reset() {
    this.tracking = false;
    this.misses = 0;
    this.gain = 1;
  }

  detect(frame, rate) {
    const result = this.analyze(frame, rate);
    if (result) {
      this.tracking = true;
      this.misses = 0;
    } else if (++this.misses >= 4) {
      this.tracking = false;
    }
    return result;
  }

  analyze(frame, rate) {
    const {real, imag, size, energy, nsdf} = this;
    const length = frame.length;
    const mean = frame.reduce((sum, value) => sum + value, 0) / length;
    real.fill(0);
    imag.fill(0);
    for (let i = 0; i < length; i++) {
      const centered = frame[i] - mean;
      real[i] = centered;
      energy[i + 1] = energy[i] + centered * centered;
    }
    const rms = Math.sqrt(energy[length] / length);
    const desired = clamp(0.04 / Math.max(rms, 1e-10), 1, 10 ** (24 / 20));
    // Boost quiet signals promptly and shed gain more gradually.
    this.gain += (desired - this.gain) * (desired > this.gain ? 0.85 : 0.26);
    if (rms * this.gain < (this.tracking ? 0.001 : 10 ** (-50 / 20))) return null;
    for (let i = 0; i < length; i++) real[i] *= this.gain;
    const gainSquared = this.gain ** 2;
    const clarityFloor = this.tracking ? 0.65 : 0.85;

    // Zero padding gives linear autocorrelation from the inverse power spectrum.
    this.fft(false);
    for (let i = 0; i < size; i++) real[i] = real[i] ** 2 + imag[i] ** 2;
    imag.fill(0);
    this.fft(true);

    // MPM normalizes each lag by the energy of the two overlapping segments.
    const max = Math.min(length - 2, Math.ceil(rate / 30) + 2);
    for (let lag = 0; lag <= max + 1; lag++) {
      const power = energy[length - lag] + energy[length] - energy[lag];
      nsdf[lag] = power > 0 ? (2 * real[lag] / size) / (power * gainSquared) : 0;
    }
    const peaks = [];
    let crossed = false;
    let best = -1;
    for (let lag = 1; lag <= max + 1; lag++) {
      if (nsdf[lag] <= 0 || lag > max) {
        if (best >= 2) peaks.push(best);
        crossed = true;
        best = -1;
      } else if (crossed && (best < 0 || nsdf[lag] > nsdf[best])) {
        best = lag;
      }
    }
    // Select the first strong positive lobe and refine its maximum.
    const highest = peaks.reduce((top, lag) => Math.max(top, nsdf[lag]), 0);
    for (const lag of peaks) {
      const a = nsdf[lag - 1];
      const b = nsdf[lag];
      const c = nsdf[lag + 1];
      if (b < Math.max(clarityFloor, highest * 0.90) || b < c) continue;
      const curvature = a - 2 * b + c;
      const delta = curvature ? 0.5 * (a - c) / curvature : 0;
      const hz = rate / (lag + delta);
      if (hz < 29.99 || hz > 1300.1) return null;
      return {hz: clamp(hz, 30, 1300), clarity: b - 0.25 * (a - c) * delta};
    }
    return null;
  }
}

class AudioEngine {
  constructor() {
    this.detector = new PitchDetector();
    this.clicks = new Set();
    this.events = [];
    this.beat = 0;
    this.timer = null;
    this.pitchEnabled = true;
  }

  async wake() {
    if (!this.context) {
      const Context = window.AudioContext;
      if (!Context) throw new Error('Audio is unavailable in this browser.');
      this.context = new Context();
      this.output = this.context.createGain();
      this.output.gain.value = 0.8;
      this.output.connect(this.context.destination);
      this.context.addEventListener('statechange', () => this.onState?.());
    }
    if (this.context.state !== 'running') await this.context.resume();
  }

  async startMic() {
    if (!navigator.mediaDevices?.getUserMedia) throw new Error('Microphone access requires HTTPS or localhost.');
    const ready = this.wake();
    let stream;
    let failed = false;
    try {
      [stream] = await Promise.all([
        navigator.mediaDevices.getUserMedia({
          audio: {channelCount: 1, echoCancellation: false, noiseSuppression: false, autoGainControl: false}
        }).then(result => {
          if (failed) result.getTracks().forEach(track => track.stop());
          stream = result;
          return result;
        }),
        ready
      ]);
      if (!this.context.audioWorklet) throw new Error('Microphone analysis requires AudioWorklet support.');
      this.workletReady ??= this.context.audioWorklet.addModule('capture.js').catch(error => {
        this.workletReady = null;
        throw error;
      });
      await this.workletReady;
      this.stream = stream;
      const context = this.context;
      this.source = context.createMediaStreamSource(stream);
      this.capture = new AudioWorkletNode(context, 'input-capture', {
        channelCount: 1, channelCountMode: 'explicit', outputChannelCount: [1]
      });
      this.capture.port.postMessage(this.pitchEnabled);
      this.capture.port.onmessage = ({data}) => {
        if (this.pitchEnabled && this.stream === stream) this.onPitch?.(this.detector.detect(data, context.sampleRate));
      };
      this.raw = context.createAnalyser();
      this.weighted = context.createAnalyser();
      this.raw.fftSize = this.weighted.fftSize = 2048;
      this.samples = new Float32Array(2048);
      this.sink = context.createGain();
      this.sink.gain.value = 0;
      this.sink.connect(context.destination);
      this.pitchFilter = context.createBiquadFilter();
      this.pitchFilter.type = 'highpass';
      this.pitchFilter.frequency.value = 70;
      this.pitchFilter.Q.value = -3;
      this.detector.reset();
      this.source.connect(this.pitchFilter).connect(this.capture).connect(this.sink);
      this.source.connect(this.raw).connect(this.sink);
      this.filters = this.makeWeighting();
      let last = this.source;
      for (const filter of this.filters) last = last.connect(filter);
      last.connect(this.weighted).connect(this.sink);
      for (const track of stream.getAudioTracks()) {
        track.addEventListener('ended', () => {
          if (this.stream !== stream) return;
          this.stopMic();
          this.onState?.();
        });
      }
    } catch (error) {
      failed = true;
      if (this.stream && this.stream === stream) this.stopMic();
      else stream?.getTracks().forEach(track => track.stop());
      throw error;
    }
  }

  makeWeighting() {
    const context = this.context;
    const rate = context.sampleRate;
    const reference = 2 * Math.PI * 1000 / rate;
    let magnitude = 1;
    // Bilinear transform of the six analog poles and four DC zeros.
    const filters = [20.598997, 20.598997, 107.65265, 737.86223, 12194.217, 12194.217].map((hz, index) => {
      const ratio = Math.PI * hz / rate;
      const pole = (ratio - 1) / (ratio + 1);
      const sign = index < 4 ? -1 : 1;
      const gain = (index < 4 ? 1 : ratio) / (ratio + 1);
      magnitude *= gain * Math.hypot(1 + sign * Math.cos(reference), sign * Math.sin(reference))
        / Math.hypot(1 + pole * Math.cos(reference), pole * Math.sin(reference));
      return context.createIIRFilter([gain, sign * gain], [1, pole]);
    });
    const normalization = context.createGain();
    normalization.gain.value = 1 / magnitude;
    return [...filters, normalization];
  }

  stopMic() {
    this.stream?.getTracks().forEach(track => track.stop());
    for (const node of [this.source, this.pitchFilter, this.capture, this.raw, this.weighted, this.sink, ...(this.filters || [])]) node?.disconnect();
    if (this.capture) this.capture.port.onmessage = null;
    this.stream = this.capture = this.source = this.pitchFilter = this.raw = this.weighted = this.sink = this.filters = null;
  }

  setPitchEnabled(enabled) {
    if (this.pitchEnabled !== enabled) this.detector.reset();
    this.pitchEnabled = enabled;
    this.capture?.port.postMessage(enabled);
  }

  db(weighted = false) {
    if (!this.stream || this.context.state !== 'running') return null;
    (weighted ? this.weighted : this.raw).getFloatTimeDomainData(this.samples);
    const power = this.samples.reduce((sum, value) => sum + value * value, 0) / this.samples.length;
    return 10 * Math.log10(Math.max(power, 1e-10));
  }

  click(time, accent) {
    const context = this.context;
    const osc = context.createOscillator();
    const envelope = context.createGain();
    osc.frequency.setValueAtTime(accent ? 1580 : 1040, time);
    osc.frequency.exponentialRampToValueAtTime(accent ? 900 : 630, time + 0.035);
    envelope.gain.setValueAtTime(0.0001, time);
    envelope.gain.exponentialRampToValueAtTime(accent ? 0.30 : 0.17, time + 0.002);
    envelope.gain.exponentialRampToValueAtTime(0.0001, time + 0.045);
    osc.connect(envelope).connect(this.output);
    this.clicks.add(osc);
    osc.onended = () => { this.clicks.delete(osc); osc.disconnect(); envelope.disconnect(); };
    osc.start(time);
    osc.stop(time + 0.05);
  }

  startMetro(getTempo, getBeats) {
    this.stopMetro();
    this.nextBeat = this.context.currentTime + 0.045;
    this.beat = 0;
    const schedule = () => {
      if (this.context.state !== 'running') return;
      const now = this.context.currentTime;
      const period = 60 / getTempo();
      const beats = getBeats();
      if (this.nextBeat < now) {
        const missed = Math.ceil((now - this.nextBeat) / period);
        this.nextBeat += missed * period;
        this.beat = (this.beat + missed) % beats;
      }
      while (this.nextBeat < now + 0.1) {
        this.beat %= beats;
        this.click(this.nextBeat, this.beat === 0);
        this.events.push({time: this.nextBeat, beat: this.beat});
        this.nextBeat += period;
        this.beat++;
      }
      while (this.events[0]?.time < now - 0.5) this.events.shift();
    };
    schedule();
    this.timer = setInterval(schedule, 25);
  }

  stopMetro() {
    clearInterval(this.timer);
    this.timer = null;
    this.events.length = 0;
    for (const click of this.clicks) click.stop();
  }

  playbackTime() {
    const stamp = this.context.getOutputTimestamp?.();
    if (stamp?.performanceTime > 0) {
      return Math.min(this.context.currentTime, stamp.contextTime + (performance.now() - stamp.performanceTime) / 1000);
    }
    return Math.max(0, this.context.currentTime - (this.context.outputLatency || this.context.baseLatency || 0));
  }

  startTone(type, hz, gain, sweep) {
    this.stopTone();
    const context = this.context;
    const osc = context.createOscillator();
    const envelope = context.createGain();
    const start = context.currentTime;
    const end = sweep ? start + sweep.duration : Infinity;
    osc.type = type;
    osc.frequency.setValueAtTime(sweep ? sweep.from : hz, start);
    envelope.gain.setValueAtTime(0, start);
    envelope.gain.linearRampToValueAtTime(gain, start + 0.018);
    osc.connect(envelope).connect(this.output);
    this.tone = {osc, envelope, start, end, sweep};
    osc.onended = () => {
      osc.disconnect();
      envelope.disconnect();
      if (this.tone?.osc === osc) {
        this.tone = null;
        this.onState?.();
      }
    };
    osc.start(start);
    if (sweep) {
      osc.frequency.exponentialRampToValueAtTime(sweep.to, end);
      envelope.gain.setTargetAtTime(0, end, 0.006);
      osc.stop(end + 0.035);
    }
  }

  updateTone(type, hz, gain) {
    const tone = this.tone;
    if (!tone) return;
    const now = this.context.currentTime;
    tone.osc.type = type;
    if (!tone.sweep) tone.osc.frequency.setTargetAtTime(hz, now, 0.015);
    if (now < tone.end) {
      tone.envelope.gain.cancelScheduledValues(now);
      tone.envelope.gain.setTargetAtTime(gain, now, 0.01);
      if (tone.sweep) tone.envelope.gain.setTargetAtTime(0, tone.end, 0.006);
    }
  }

  stopTone() {
    const tone = this.tone;
    if (!tone) return;
    this.tone = null;
    const now = this.context.currentTime;
    tone.envelope.gain.cancelScheduledValues(now);
    tone.envelope.gain.setTargetAtTime(0, now, 0.006);
    tone.osc.stop(Math.min(now + 0.035, tone.end + 0.035));
  }
}
