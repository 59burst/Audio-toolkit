# Stringbench

A static, offline-capable musician’s toolkit with a chromatic tuner, metronome, tone generator, and level meter. The JavaScript and styles ship as plain source. Microphone audio stays on the device.

## Run locally

From this directory, run:

```sh
python3 -m http.server 8000
```

Open http://localhost:8000 in desktop Chrome. Use the Enable microphone button in Tuner or Level Meter to grant permission. Opening the HTML from disk does not provide the secure context needed by the microphone and service worker.

## Deploy and install

Upload the files alongside this README to the same directory on any HTTPS static host. Subdirectories work. Open the deployed URL once online to cache the app shell. On iPhone Safari (iOS 17+), open the Share menu and choose **Add to Home Screen**. On desktop Chrome, use the browser’s install control when available. Installed or in the browser, microphone access is subject to site permission. Audio starts from a button tap.

When releasing updated files, increment the cache version in `sw.js`. Once all copies of the old app are closed, the next visit will use the updated shell.

## Measurement and tuning

The tuner uses the McLeod Pitch Method, with FFT-based autocorrelation, normalized square difference peak selection, and parabolic interpolation. Pitch detection runs in an AudioWorklet. Its input goes through a 70 Hz high-pass filter and up to 24 dB of automatic gain before detection. The level meter uses its own unboosted input path.

The tuner shows live candidates at NSDF clarity of 0.75 or more. A note commits after three agreeing frames within 20 cents. If those frames split across an octave, the side with the higher mean clarity wins. An octave change from a committed reading requires six consecutive agreeing frames. The tuner smooths the displayed reading with a three-frame median followed by a two-frame moving average, and holds the reading until raw input stays below −78 dBFS for two seconds. The graph shows the most recent eight seconds of tracked pitch.

Tuner settings below the readout let you choose the in-tune tolerance, A4 reference, temperament, and guitar preset. Sweetened tuning applies the listed per-string offsets. The tuner remains chromatic with every preset.

The diagnostics strip shows raw RMS, frame rate, sample rate, NSDF clarity, and detector frequency. Settings → Download CSV exports the current microphone session, including per-hop raw RMS and held peak on Level Meter. The source column identifies the active instrument. Time is in milliseconds from the microphone start request.

Choose Tweed or Brown for the cabinet using the theme control on the main screen. On Metronome, tap the jewel lamp to start or stop. Drag the pendulum weight down for faster tempo, or use the slider or step buttons. Tap the BPM or beats-per-bar value to edit it in place.

The Level Meter offers the same CSV export as Settings. View Sonification opens a strip chart of this session’s Level Meter readings in place of the meter display.

The level meter holds the highest RMS reading until reset. The estimated SPL starts with a nominal 100 dB reference for 0 dBFS. Use a known acoustic reference and adjust Calibration offset to match it. The optional A-weighting applies to the SPL estimate only. Estimates depend on microphone response, input gain, and system processing.

Switching modules stops any running tone or metronome. An enabled microphone remains available across all tabs and can be disabled from either. Closing the page releases the microphone.
