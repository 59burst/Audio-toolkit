const $ = id => document.getElementById(id);
const engine = new AudioEngine();
const noteNames = ['C','C♯','D','D♯','E','F','F♯','G','G♯','A','A♯','B'];
const mod = (n, d) => ((n % d) + d) % d;
const noteName = midi => noteNames[mod(midi, 12)] + (Math.floor(midi / 12) - 1);
const signed = (value, digits = 0) => {
  const number = Number(value.toFixed(digits));
  return (number > 0 ? '+' : '') + number.toFixed(digits).replace('-', '−');
};
const presets = {
  standard: {name:'Standard guitar', notes:[40,45,50,55,59,64]},
  drop: {name:'Drop D guitar', notes:[38,45,50,55,59,64]},
  open: {name:'Open G guitar', notes:[38,43,50,55,59,62]},
  sweet: {name:'Sweetened guitar', notes:[40,45,50,55,59,64], offsets:[-3,-2,0,-1,-4,-2]}
};

const fifth = 1200 * Math.log2(3 / 2);
const pythComma = 12 * fifth - 8400;
const syntonicComma = 1200 * Math.log2(81 / 80);
// Follow the circle of fifths, then normalize each pitch class relative to A.
function temperamentOffsets(kind) {
  const offsets = Array(12).fill(0);
  if (kind === 'equal') return offsets;
  if (kind === 'werck') {
    const chain = [0,7,2,9,4,11,6,1,8,3,10,5];
    for (let i = 1; i < chain.length; i++) {
      const narrowed = [1,2,3,6].includes(i);
      offsets[chain[i]] = offsets[chain[i - 1]] + fifth - 700 - (narrowed ? pythComma / 4 : 0);
    }
  } else {
    const distance = kind === 'meantone' ? fifth - syntonicComma / 4 : fifth;
    for (let step = -3; step <= 8; step++) {
      offsets[mod(7 * step, 12)] = step * (distance - 700);
    }
  }
  return offsets.map(value => value - offsets[9]);
}
const temperaments = Object.fromEntries(['equal','pyth','meantone','werck'].map(name => [name, temperamentOffsets(name)]));

const settings = {theme:'blue', a4:440, temperament:'equal', preset:'standard', response:2, tolerance:5};
try {
  const saved = JSON.parse(localStorage.getItem('soundbench-settings')) || {};
  if (['blue','orange'].includes(saved.theme)) settings.theme = saved.theme;
  if (Object.hasOwn(temperaments, saved.temperament)) settings.temperament = saved.temperament;
  if (Object.hasOwn(presets, saved.preset)) settings.preset = saved.preset;
  if (Number.isFinite(saved.a4)) settings.a4 = clamp(saved.a4, 415, 466);
  if ([2,5,10].includes(saved.tolerance)) settings.tolerance = saved.tolerance;
  if ([1,2,3,4].includes(saved.response)) settings.response = saved.response;
  else if (Number.isFinite(saved.damping)) settings.response = clamp(4 - Math.round(saved.damping / 25), 1, 4);
} catch {}

function targetFrequency(midi, guitar = true) {
  const preset = presets[settings.preset];
  const guitarOffset = guitar ? preset.offsets?.[preset.notes.indexOf(midi)] ?? 0 : 0;
  const offset = temperaments[settings.temperament][mod(midi, 12)] + guitarOffset;
  return settings.a4 * 2 ** ((midi - 69) / 12 + offset / 1200);
}

const modules = {
  tuner: {title:'Chromatic Tuner', subtitle:'PITCH DETECTION', gauge:'CENT DEVIATION', mode:'LIVE INPUT', labels:['NOTE','FREQUENCY','DEVIATION'], ticks:['−50','−25','0','+25','+50'], captions:['FLAT','IN TUNE','SHARP']},
  metro: {title:'Metronome', subtitle:'TEMPO & TIME', gauge:'TEMPO SCALE', mode:'AUDIO CLOCK', labels:['TEMPO','BEAT','BEATS / BAR'], ticks:['30','83','135','188','240'], captions:['SLOW','BPM','FAST']},
  tone: {title:'Tone Generator', subtitle:'SIGNAL GENERATOR', gauge:'FREQUENCY SCALE', mode:'OSCILLATOR', labels:['FREQUENCY','NOTE','GAIN'], ticks:['20','112','632','3.6k','20k'], captions:['LOW','HERTZ','HIGH']},
  level: {title:'Level Meter', subtitle:'INPUT MEASUREMENT', gauge:'INPUT LEVEL', mode:'LIVE INPUT', labels:['RMS LEVEL','PEAK HOLD','SPL EST.'], ticks:['−60','−45','−30','−15','0'], captions:['QUIET','DBFS','FULL SCALE']}
};
let active = 'tuner';
let pitch = null;
let lastPitchTime = -Infinity;
let committedNote = null;
let candidateNote = null;
let candidateFrames = 0;
let centsHistory = [];
let medianHistory = [];
let lastAcceptedTime = -Infinity;
let lastFrameInTune = false;
let inTuneTime = 0;
let trackingGate = false;
let missedFrames = 0;
let sessionStart;
let sessionLog = [];
let latestDebug = null;
let graphTime = 0;
let graphPoints = [];
let graphDirty = true;
let latchedNote = null;
const pitchGap = 120;
const sessionGap = 600;
const graphWindow = 8000;
const pitchY = cents => 88 - clamp(cents, -50, 50) * 1.44;

function drawPitchTrace() {
  graphDirty = false;
  const stride = Math.max(1, Math.ceil(graphPoints.length / 200));
  const sampled = [];
  let start = false;
  for (const [index, point] of graphPoints.entries()) {
    start ||= point.start;
    if (index % stride !== 0 && index !== graphPoints.length - 1) continue;
    sampled.push({...point, start});
    start = false;
  }
  if (sampled.length > 200) sampled.shift();
  const points = sampled.map(point => [
    605 - (graphTime - point.time) * 550 / graphWindow,
    pitchY(point.cents),
    point.start
  ]);
  $('pitchTrace').setAttribute('d', points.map(([x,y,start], index) =>
    (index === 0 || start ? 'M' : 'L') + x.toFixed(2) + ' ' + y.toFixed(2)).join(' '));
  const last = points.at(-1);
  $('pitchPoint').setAttribute('visibility', last ? 'visible' : 'hidden');
  if (last) {
    $('pitchPoint').setAttribute('cx', last[0]);
    $('pitchPoint').setAttribute('cy', last[1]);
  }
}

function resetPitchHistory() {
  centsHistory = [];
  medianHistory = [];
  candidateNote = null;
  candidateFrames = 0;
  inTuneTime = 0;
}

function updateOctaveReference() {
  const notes = [...presets[settings.preset].notes];
  if (committedNote !== null) notes.push(committedNote);
  const frequencies = {};
  for (const midi of notes) {
    for (let neighbor = midi - 3; neighbor <= midi + 3; neighbor++) {
      frequencies[neighbor] = targetFrequency(neighbor);
    }
  }
  engine.setOctaveReference({a4: settings.a4, notes, frequencies});
}

function resetPitch() {
  pitch = null;
  committedNote = latchedNote = null;
  lastPitchTime = lastAcceptedTime = -Infinity;
  lastFrameInTune = false;
  resetPitchHistory();
  updateOctaveReference();
  graphTime = 0;
  graphPoints = [];
  graphDirty = true;
}

function resetGateDisplay() {
  trackingGate = false;
  missedFrames = 0;
  latestDebug = null;
}
let peak = -Infinity;
let toneHz = 440;
let micPending = false;
let audioPending = false;
let levelValue = null;
let weightedValue = null;
let levelTime = -Infinity;
const beatLights = $('beatLights');
const signedUnit = '¢';
const polar = (radius, angle) => {
  const r = angle * Math.PI / 180;
  return [310 + radius * Math.sin(r), 222 - radius * Math.cos(r)];
};
const arc = radius => {
  const [x1,y1] = polar(radius, -66);
  const [x2,y2] = polar(radius, 66);
  return 'M' + x1 + ' ' + y1 + ' A' + radius + ' ' + radius + ' 0 0 1 ' + x2 + ' ' + y2;
};
function angleAt(position) { return -66 + 132 * position; }

function drawScale() {
  const {ticks} = modules[active];
  const scale = [`<path class="rim" d="${arc(175)}"/><path class="arc" d="${arc(175)}"/>`];
  for (let i = 0; i <= 40; i++) {
    const angle = angleAt(i / 40);
    const major = i % 10 === 0;
    const [x1,y1] = polar(major ? 157 : i % 5 === 0 ? 163 : 168, angle);
    const [x2,y2] = polar(184, angle);
    scale.push(`<line class="tick ${major ? 'major' : ''}" x1="${x1}" y1="${y1}" x2="${x2}" y2="${y2}"/>`);
    if (major) {
      const [x,y] = polar(207, angle);
      scale.push(`<text x="${x}" y="${y + 7}">${ticks[i / 10]}</text>`);
    }
  }
  $('dialScale').innerHTML = scale.join('');
  const digital = [];
  for (let i = 0; i < 41; i++) digital.push(`<rect class="segment" x="${46 + 13 * i}" y="93" width="8" height="44" rx="1"/>`);
  for (let i = 0; i < ticks.length; i++) digital.push(`<text x="${50 + i * 130}" y="178">${ticks[i]}</text>`);
  digital.push('<line class="marker" x1="310" x2="310" y1="76" y2="86" visibility="hidden"/>');
  $('digitalScale').innerHTML = digital.join('');
}

function updateGauge(position, live = true, marker = null) {
  const value = clamp(position, 0, 1);
  $('needle').style.transform = `rotate(${angleAt(value)}deg)`;
  $('needle').style.opacity = live ? 1 : 0.28;
  if (settings.theme !== 'orange') return;
  const start = active === 'tuner' ? 20 : 0;
  const end = Math.round(value * 40);
  const rule = $('digitalScale');
  for (let i = 0; i < 41; i++) {
    rule.children[i].classList.toggle('lit', live && i >= Math.min(start,end) && i <= Math.max(start,end));
  }
  const line = rule.lastElementChild;
  line.setAttribute('visibility', marker === null ? 'hidden' : 'visible');
  if (marker !== null) {
    const x = 50 + 520 * clamp(marker,0,1);
    line.setAttribute('x1', x);
    line.setAttribute('x2', x);
  }
}

function read(id, value, unit = '') {
  const element = $(id);
  const key = value + '|' + unit;
  if (element.dataset.value === key) return;
  element.dataset.value = key;
  element.textContent = value;
  if (unit) {
    const small = document.createElement('small');
    small.textContent = ' ' + unit;
    element.append(small);
  }
}

function setStatus(text, live) {
  const status = $('status');
  if (status.lastElementChild.textContent !== text) status.lastElementChild.textContent = text;
  status.classList.toggle('live', live);
}

function message(text = '') {
  $('message').textContent = text;
  $('message').hidden = !text;
}

function showModule(name) {
  if (name !== active) {
    engine.stopMetro();
    engine.stopTone();
    message();
  }
  if (active !== name) resetGateDisplay();
  active = name;
  debugLine.style.display = name === 'tuner' ? '' : 'none';
  document.body.dataset.module = name;
  engine.setPitchEnabled(name === 'tuner');
  document.querySelector('.instrument').classList.remove('pitch-dim', 'pitch-tuned');
  $('analogFace').hidden = name === 'tuner' || name === 'tone';
  $('tunerGraph').hidden = name !== 'tuner';
  const module = modules[name];
  $('moduleTitle').textContent = module.title;
  $('subtitle').textContent = module.subtitle;
  $('gaugeLabel').textContent = module.gauge;
  $('faceMode').textContent = module.mode;
  ['primary','secondary','tertiary'].forEach((id, i) => { $(id + 'Label').textContent = module.labels[i]; });
  ['left','center','right'].forEach((id, i) => { $(id + 'Caption').textContent = module.captions[i]; });
  for (const key of Object.keys(modules)) $(key + 'Controls').hidden = key !== name;
  $('micControls').hidden = name !== 'tuner' && name !== 'level';
  for (const button of document.querySelectorAll('[data-module]')) {
    if (button.dataset.module === name) button.setAttribute('aria-current', 'page');
    else button.removeAttribute('aria-current');
  }
  drawScale();
  updateControls();
  render(performance.now());
}

function refreshSettings() {
  document.documentElement.dataset.theme = settings.theme;
  document.querySelector('meta[name="theme-color"]').content = settings.theme === 'blue' ? '#090f18' : '#15100c';
  for (const [id, value] of Object.entries(settings)) {
    if (id !== 'theme') $(id).value = value;
  }
  const nextTheme = settings.theme === 'blue' ? 'Orange Digital' : 'Blue Analog';
  $('themeToggle').textContent = nextTheme.split(' ')[0];
  $('themeToggle').setAttribute('aria-label', 'Switch to ' + nextTheme);
  $('themeToggle').title = 'Switch to ' + nextTheme;
  $('pitchBand').setAttribute('y', pitchY(settings.tolerance));
  $('pitchBand').setAttribute('height', settings.tolerance * 2.88);
  $('a4Value').value = settings.a4 + ' Hz';
  $('reference').textContent = 'A4 · ' + settings.a4 + ' Hz';
  const temperament = $('temperament').selectedOptions[0].textContent;
  $('temperamentSummary').textContent = temperament + ' temperament';
  const preset = presets[settings.preset];
  $('presetSummary').textContent = preset.name;
  $('presetSummary').title = preset.notes.map(noteName).join(' · ');
  $('presetStrings').replaceChildren(...preset.notes.map(midi => {
    const span = document.createElement('span');
    span.textContent = noteName(midi);
    span.dataset.note = midi;
    return span;
  }));
  $('strings').textContent = preset.notes.map((midi, i) => {
    const offset = preset.offsets?.[i];
    return noteName(midi) + (offset ? ' ' + signed(offset) + '¢' : '');
  }).join(' · ');
}
function saveSettings() {
  try { localStorage.setItem('soundbench-settings', JSON.stringify(settings)); } catch {}
}
$('themeToggle').onclick = () => {
  settings.theme = settings.theme === 'blue' ? 'orange' : 'blue';
  refreshSettings();
  saveSettings();
};
for (const id of Object.keys(settings).filter(key => key !== 'theme')) {
  $(id).addEventListener('input', () => {
    settings[id] = typeof settings[id] === 'number' ? Number($(id).value) : $(id).value;
    if (id === 'tolerance') {
      inTuneTime = 0;
      lastFrameInTune = false;
    } else if (id !== 'response') {
      resetPitchHistory();
      updateOctaveReference();
    }
    if (id !== 'response') refreshSettings();
    saveSettings();
  });
}
$('settingsOpen').onclick = () => $('settingsDialog').showModal();
for (const button of document.querySelectorAll('[data-module]')) {
  button.onclick = () => { if (button.dataset.module !== active) showModule(button.dataset.module); };
}

function updateControls() {
  const mic = Boolean(engine.stream);
  const interrupted = mic && engine.context.state !== 'running';
  $('micButton').textContent = micPending ? 'Waiting for permission…' : interrupted ? 'Resume microphone' : mic ? 'Disable microphone' : 'Enable microphone';
  $('micButton').disabled = micPending;
  $('micHelp').textContent = active === 'level'
    ? 'Measure the signal arriving at your microphone.'
    : 'Enable the mic, then play a single sustained note.';
  if (mic) $('micHelp').textContent = interrupted ? 'Tap Resume to restore audio input.' : active === 'level'
    ? 'Live RMS and peak readings from this device.'
    : 'Play one note at a time for a steady reading.';
  $('metroButton').textContent = engine.timer !== null ? 'Stop metronome' : 'Start metronome';
  $('toneButton').textContent = engine.tone ? 'Stop tone' : 'Play tone';
  $('sweepButton').textContent = engine.tone?.sweep ? 'Stop sweep' : 'Start sweep';
  for (const id of ['metroButton','toneButton','sweepButton']) $(id).disabled = audioPending;
}
engine.onState = updateControls;
$('micButton').onclick = async () => {
  message();
  if (!engine.stream) {
    $('micDialog').showModal();
  } else if (engine.context.state !== 'running') {
    try { await engine.wake(); } catch { message('Audio input could not resume. Try again.'); }
    updateControls();
  } else {
    engine.stopMic();
    resetPitch();
    resetGateDisplay();
    peak = -Infinity;
    levelValue = null;
    weightedValue = null;
    levelTime = -Infinity;
    updateControls();
  }
};
$('micContinue').onclick = async () => {
  $('micDialog').close();
  micPending = true;
  peak = -Infinity;
  levelTime = -Infinity;
  updateControls();
  try {
    resetPitch();
    sessionStart = performance.now();
    sessionLog = [];
    resetGateDisplay();
    await engine.startMic();
  } catch (error) {
    if (['NotAllowedError','SecurityError'].includes(error.name)) {
      message('Microphone access was blocked. Allow it in your browser’s site settings, then try again.');
    } else if (error.name === 'NotFoundError') {
      message('No microphone was found. Connect one and try again.');
    } else {
      message(error.message || 'The microphone could not be opened. Try again.');
    }
  } finally {
    micPending = false;
    updateControls();
  }
};

let statusPress;
const statusArea = $('status');
const debugLine = $('pitchDebug');
const cancelStatusPress = () => clearTimeout(statusPress);
statusArea.addEventListener('pointerdown', event => {
  if (event.button !== 0 || active !== 'tuner') return;
  cancelStatusPress();
  statusPress = setTimeout(() => { debugLine.hidden = !debugLine.hidden; }, 550);
});
for (const type of ['pointerup', 'pointercancel', 'pointerleave']) {
  statusArea.addEventListener(type, cancelStatusPress);
}
statusArea.addEventListener('contextmenu', event => event.preventDefault());

$('downloadCsv').onclick = () => {
  const header = 'time,rmsDb,clarity,gate state,hz,cents,committed note';
  const blob = new Blob([header + '\r\n', sessionLog.join('\r\n')], {type: 'text/csv;charset=utf-8'});
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = 'soundbench-session.csv';
  document.body.append(link);
  link.click();
  link.remove();
  setTimeout(() => URL.revokeObjectURL(url), 30000);
};

function updatePitchDisplay(hz, now, hopMs) {
  const midiEstimate = Math.round(69 + 12 * Math.log2(hz / settings.a4));
  let closest = Infinity;
  let note;
  for (let midi = midiEstimate - 1; midi <= midiEstimate + 1; midi++) {
    const cents = 1200 * Math.log2(hz / targetFrequency(midi));
    if (Math.abs(cents) < Math.abs(closest)) {
      closest = cents;
      note = midi;
    }
  }

  const runningCents = committedNote === null ? Infinity : 1200 * Math.log2(hz / targetFrequency(committedNote));
  if (note === committedNote) {
    candidateNote = null;
    candidateFrames = 0;
  } else {
    candidateFrames = candidateNote === note ? candidateFrames + 1 : 1;
    candidateNote = note;
  }
  const changedNote = note !== committedNote
    && (candidateFrames >= 3 || Math.abs(runningCents) - Math.abs(closest) > 20);
  if (changedNote) {
    committedNote = note;
    latchedNote = null;
    resetPitchHistory();
    updateOctaveReference();
  }

  const rawCents = changedNote ? closest : runningCents;
  centsHistory.push(rawCents);
  if (centsHistory.length > 3) centsHistory.shift();
  const sorted = [...centsHistory].sort((a,b) => a - b);
  const middle = Math.floor(sorted.length / 2);
  const median = sorted.length === 2 ? (sorted[0] + sorted[1]) / 2 : sorted[middle];
  medianHistory.push(median);
  if (medianHistory.length > 4) medianHistory.shift();
  const recent = medianHistory.slice(-settings.response);
  const cents = recent.reduce((sum, value) => sum + value, 0) / recent.length;
  const target = targetFrequency(committedNote);

  const withinTolerance = note === committedNote && Math.abs(cents) <= settings.tolerance;
  if (withinTolerance) {
    if (lastFrameInTune && !changedNote) inTuneTime += hopMs;
    if (inTuneTime >= 400) latchedNote = committedNote;
  } else if (note === committedNote) {
    inTuneTime = 0;
  }
  lastFrameInTune = withinTolerance;

  const elapsed = now - lastPitchTime;
  const visualGap = elapsed > pitchGap;
  if (graphPoints.length) graphTime += visualGap ? 25 : elapsed;
  graphPoints.push({time: graphTime, cents, start: visualGap || changedNote});
  while (graphPoints[0]?.time < graphTime - graphWindow) graphPoints.shift();
  graphDirty = true;
  lastPitchTime = now;
  pitch = {note: committedNote, hz: target * 2 ** (cents / 1200), cents};
}

engine.onPitch = ({hz, clarity, rmsDb}) => {
  const now = performance.now();
  const rate = engine.context.sampleRate;
  // Mirror the worklet's transition for diagnostics. It decides whether each hop passes.
  if (hz !== null) {
    trackingGate = true;
    missedFrames = 0;
  } else if (trackingGate && ++missedFrames >= 12) {
    trackingGate = false;
  }
  const gate = trackingGate ? 'track' : 'acquire';
  latestDebug = {rmsDb, clarity, gate, rate};

  if (lastAcceptedTime !== -Infinity && now - lastAcceptedTime >= sessionGap) {
    resetPitchHistory();
    lastAcceptedTime = -Infinity;
    lastFrameInTune = false;
  }
  if (hz !== null) {
    updatePitchDisplay(hz, now, 1024000 / rate);
    lastAcceptedTime = now;
  } else {
    candidateFrames = 0;
    lastFrameInTune = false;
  }
  sessionLog.push([
    (now - sessionStart).toFixed(2),
    rmsDb.toFixed(2), clarity.toFixed(4), gate,
    hz?.toFixed(3) ?? '', hz === null ? '' : pitch.cents.toFixed(3),
    committedNote === null ? '' : noteName(committedNote)
  ].join(','));
};

function bpm() { return Number($('bpm').value); }
function barBeats() { return Number($('beats').value); }
function refreshMetro() {
  $('bpmValue').value = bpm() + ' BPM';
  if (beatLights.children.length !== barBeats()) {
    beatLights.replaceChildren(...Array.from({length:barBeats()}, () => document.createElement('span')));
  }
}
$('bpm').oninput = refreshMetro;
$('beats').onchange = refreshMetro;
let taps = [];
$('tap').onclick = () => {
  const now = performance.now();
  if (taps.length && now - taps.at(-1) > 2300) taps = [];
  if (taps.length && now - taps.at(-1) < 200) return;
  taps.push(now);
  if (taps.length > 6) taps.shift();
  if (taps.length > 1) {
    $('bpm').value = clamp(Math.round(60000 * (taps.length - 1) / (now - taps[0])), 30, 240);
    refreshMetro();
  }
};

async function startOutput(module, start) {
  if (audioPending) return;
  audioPending = true;
  updateControls();
  message();
  try {
    await engine.wake();
    if (active === module) start();
  } catch (error) {
    message(error.message || 'Audio output could not start.');
  } finally {
    audioPending = false;
    updateControls();
  }
}

$('metroButton').onclick = () => {
  if (engine.timer !== null) {
    engine.stopMetro();
    updateControls();
  } else {
    startOutput('metro', () => engine.startMetro(bpm, barBeats));
  }
};

const tonePosition = hz => Math.log(hz / 20) / Math.log(1000);
const fromTonePosition = position => 20 * 1000 ** position;
const toneGain = () => Number($('gain').value) / 100 * 0.5;
function setTone(hz) {
  toneHz = Math.round(clamp(hz,20,20000) * 10) / 10;
  $('frequency').value = toneHz.toFixed(1);
  $('frequencyRange').value = Math.round(tonePosition(toneHz) * 10000);
  refreshTone();
}
function refreshTone() {
  $('gainValue').value = $('gain').value + '%';
  engine.updateTone($('waveform').value, toneHz, toneGain());
}
$('frequency').onchange = () => setTone(Number.isFinite($('frequency').valueAsNumber) ? $('frequency').valueAsNumber : toneHz);
$('frequencyRange').oninput = () => setTone(fromTonePosition(Number($('frequencyRange').value) / 10000));
$('lowerWhole').onclick = () => setTone(toneHz - 1);
$('raiseWhole').onclick = () => setTone(toneHz + 1);
$('lower').onclick = () => setTone(toneHz - 0.1);
$('raise').onclick = () => setTone(toneHz + 0.1);
$('gain').oninput = refreshTone;
$('waveform').onchange = refreshTone;
for (const midi of [60,62,64,65,67,69,71]) {
  const button = document.createElement('button');
  button.className = 'button';
  button.type = 'button';
  button.textContent = noteName(midi);
  button.onclick = () => setTone(targetFrequency(midi, false));
  $('noteButtons').append(button);
}
$('toneButton').onclick = () => {
  if (engine.tone) {
    engine.stopTone();
    updateControls();
  } else {
    startOutput('tone', () => engine.startTone($('waveform').value, toneHz, toneGain()));
  }
};
$('sweepButton').onclick = () => {
  if (engine.tone?.sweep) {
    engine.stopTone();
    updateControls();
    return;
  }
  const fields = ['sweepStart','sweepEnd','sweepDuration'].map($);
  const invalid = fields.find(field => !Number.isFinite(field.valueAsNumber) || !field.validity.valid);
  if (invalid) {
    message('Enter frequencies from 20 to 20,000 Hz and a duration from 0.1 to 120 seconds.');
    invalid.focus();
    return;
  }
  const [from,to,duration] = fields.map(field => field.valueAsNumber);
  startOutput('tone', () => engine.startTone($('waveform').value, toneHz, toneGain(), {from,to,duration}));
};
$('offset').oninput = () => { $('offsetValue').value = signed(Number($('offset').value)) + ' dB'; };
$('resetPeak').onclick = () => { peak = -Infinity; };

function render(now) {
  if (active === 'tuner') {
    const live = Boolean(engine.stream && engine.context.state === 'running');
    const age = now - lastPitchTime;
    const tracking = live && pitch && age <= pitchGap;
    const inTune = pitch && latchedNote === pitch.note;
    const display = document.querySelector('.instrument');
    display.classList.toggle('pitch-dim', Boolean(pitch && age > 2500));
    display.classList.toggle('pitch-tuned', Boolean(inTune));
    read('primary', pitch ? noteName(pitch.note) : '—');
    read('secondary', pitch ? pitch.hz.toFixed(1) : '—', 'Hz');
    read('tertiary', pitch ? signed(pitch.cents, 1) : '—', signedUnit);
    for (const string of $('presetStrings').children) {
      const matched = Boolean(pitch && Number(string.dataset.note) === pitch.note);
      const checked = matched && inTune;
      string.classList.toggle('matched', matched);
      string.classList.toggle('checked', Boolean(checked));
      const label = noteName(Number(string.dataset.note)) + (checked ? ' ✓' : '');
      if (string.textContent !== label) string.textContent = label;
    }
    setStatus(inTune ? '✓ In tune' : tracking ? 'Tracking' : live ? (pitch ? 'Signal lost' : 'Listening') : micPending ? 'Connecting' : engine.stream ? 'Mic paused' : 'Mic off', Boolean(inTune || live));
  } else if (active === 'metro') {
    const running = engine.timer !== null && engine.context.state === 'running';
    const audioTime = running ? engine.playbackTime() : 0;
    const beat = running ? engine.events.findLast(event => event.time <= audioTime) : null;
    const beatIndex = beat ? beat.beat % barBeats() : -1;
    Array.from(beatLights.children).forEach((light, i) => light.classList.toggle('on', i === beatIndex));
    beatLights.setAttribute('aria-label', beatIndex >= 0 ? 'Beat ' + (beatIndex + 1) : 'Beat indicator');
    updateGauge((bpm() - 30) / 210);
    read('primary', bpm(), 'BPM');
    read('secondary', beatIndex >= 0 ? beatIndex + 1 : '—');
    read('tertiary', barBeats());
    setStatus(running ? 'Running' : engine.timer !== null ? 'Paused' : 'Stopped', running);
  } else if (active === 'tone') {
    const tone = engine.tone;
    const running = Boolean(tone && engine.context.state === 'running');
    let hz = toneHz;
    if (tone?.sweep) {
      const {from,to,duration} = tone.sweep;
      const position = clamp((engine.playbackTime() - tone.start) / duration, 0, 1);
      hz = from * (to / from) ** position;
    }
    read('primary', hz.toFixed(1), 'Hz');
    read('secondary', noteName(Math.round(69 + 12 * Math.log2(hz / settings.a4))));
    read('tertiary', $('gain').value, '%');
    setStatus(running ? tone.sweep ? 'Sweeping' : 'Playing' : tone ? 'Paused' : 'Stopped', running);
  } else {
    const live = Boolean(engine.stream && engine.context.state === 'running');
    if (live && now - levelTime >= 40) {
      levelTime = now;
      levelValue = engine.db();
      weightedValue = $('weighting').checked ? engine.db(true) : levelValue;
      if (levelValue !== null) peak = Math.max(peak, levelValue);
    }
    const show = live && levelValue !== null;
    const display = value => Number.isFinite(value) && value > -100 ? value.toFixed(1).replace('-', '−') : '−∞';
    // The nominal reference maps 0 dBFS to 100 dB SPL before calibration.
    const estimate = weightedValue + 100 + Number($('offset').value);
    updateGauge(show ? (levelValue + 60) / 60 : 0, show,
      show && Number.isFinite(peak) ? (peak + 60) / 60 : null);
    read('primary', show ? display(levelValue) : '—', 'dBFS');
    read('secondary', show ? display(peak) : '—', 'dBFS');
    read('tertiary', show ? weightedValue > -100 ? estimate.toFixed(1) : '−∞' : '—', $('weighting').checked ? 'dBA' : 'dB');
    setStatus(live ? 'Measuring' : micPending ? 'Connecting' : engine.stream ? 'Mic paused' : 'Mic off', live);
  }
}

function frame(now) {
  if (active === 'tuner') {
    if (graphDirty) drawPitchTrace();
    if (!debugLine.hidden) {
      const info = latestDebug;
      const text = info
        ? `${info.rmsDb.toFixed(1)} dBFS · NSDF ${info.clarity.toFixed(2)} · ${info.gate} · ${info.rate} Hz`
        : `— dBFS · NSDF — · acquire · ${engine.context?.sampleRate ?? '—'} Hz`;
      if (debugLine.textContent !== text) debugLine.textContent = text;
    }
  }
  render(now);
  requestAnimationFrame(frame);
}

refreshSettings();
updateOctaveReference();
refreshMetro();
setTone(440);
showModule('tuner');
requestAnimationFrame(frame);

window.addEventListener('pagehide', () => {
  engine.stopMic();
  engine.stopMetro();
  engine.stopTone();
  updateControls();
});
if ('serviceWorker' in navigator) {
  navigator.serviceWorker.register('sw.js').catch(error => console.warn('Offline setup failed:', error));
}
